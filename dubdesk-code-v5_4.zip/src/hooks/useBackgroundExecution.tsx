import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";

/**
 * Unified background-execution layer for long dubbing runs.
 *
 * Combines three browser techniques so processing survives a hidden tab,
 * a locked screen and OS timer throttling:
 *   1. Screen Wake Lock API — prevents display sleep, re-acquired on visibility change.
 *   2. Dedicated Web Worker — heartbeat + offloaded API communication.
 *   3. Service Worker + silent audio loop — fallback that keeps the media/JS
 *      context alive when the screen actually turns off.
 *
 * All pieces are best-effort: any unsupported API degrades silently.
 */

type WakeLockLike = { released: boolean; release: () => Promise<void>; addEventListener: (t: string, cb: () => void) => void };

export type BackgroundExecution = {
  /** true while at least one job holds the background lock */
  active: boolean;
  /** ticks received from the worker heartbeat (proof the thread is alive) */
  beats: number;
  wakeLock: boolean;
  /** Hold the background lock; returns a release function. Nested calls are ref-counted. */
  begin: (label?: string) => () => void;
  /** Run an async job with the background lock held for its whole duration. */
  withBackground: <T>(label: string, fn: () => Promise<T>) => Promise<T>;
  /**
   * Execute a POST request on the worker thread (keeps running while the tab
   * sleeps). Returns null when the worker is unavailable or the call fails, so
   * callers can fall back to the normal main-thread path.
   */
  offloadJson: <T>(url: string, body: unknown) => Promise<T | null>;
};

const Ctx = createContext<BackgroundExecution | null>(null);

export function BackgroundExecutionProvider({ children }: { children: ReactNode }) {
  const [active, setActive] = useState(false);
  const [beats, setBeats] = useState(0);
  const [wakeLock, setWakeLock] = useState(false);

  const countRef = useRef(0);
  const lockRef = useRef<WakeLockLike | null>(null);
  const workerRef = useRef<Worker | null>(null);
  const audioRef = useRef<{ ctx: AudioContext; stop: () => void } | null>(null);
  const pending = useRef(new Map<string, (r: { ok: boolean; body?: string }) => void>());
  const swRef = useRef<ServiceWorker | null>(null);

  /* ---------------- Screen Wake Lock ---------------- */

  const acquireWakeLock = useCallback(async () => {
    const nav = navigator as Navigator & { wakeLock?: { request: (t: "screen") => Promise<WakeLockLike> } };
    if (!nav.wakeLock || lockRef.current) return;
    try {
      const lock = await nav.wakeLock.request("screen");
      lockRef.current = lock;
      setWakeLock(true);
      lock.addEventListener("release", () => {
        lockRef.current = null;
        setWakeLock(false);
      });
    } catch {
      setWakeLock(false);
    }
  }, []);

  const releaseWakeLock = useCallback(async () => {
    try {
      await lockRef.current?.release();
    } catch {
      /* ignore */
    }
    lockRef.current = null;
    setWakeLock(false);
  }, []);

  // Re-acquire the lock (and resume the silent loop) whenever the page becomes
  // visible again, or the page is restored from the bfcache, mid-run.
  useEffect(() => {
    const revive = () => {
      if (countRef.current === 0) return;
      if (document.visibilityState === "visible") void acquireWakeLock();
      // Some browsers suspend the AudioContext when the screen turns off.
      void audioRef.current?.ctx.resume().catch(() => undefined);
      swRef.current?.postMessage({ type: "KEEPALIVE_PING" });
    };
    document.addEventListener("visibilitychange", revive);
    window.addEventListener("pageshow", revive);
    window.addEventListener("focus", revive);
    return () => {
      document.removeEventListener("visibilitychange", revive);
      window.removeEventListener("pageshow", revive);
      window.removeEventListener("focus", revive);
    };
  }, [acquireWakeLock]);


  /* ---------------- Service worker ---------------- */

  useEffect(() => {
    if (!("serviceWorker" in navigator)) return;
    let cancelled = false;
    navigator.serviceWorker
      .register("/bg-keepalive-sw.js", { scope: "/" })
      .then((reg) => {
        if (!cancelled) swRef.current = reg.active ?? reg.waiting ?? reg.installing;
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, []);

  /* ---------------- Silent audio loop ---------------- */

  const startSilentAudio = useCallback(() => {
    if (audioRef.current) return;
    try {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AC();
      const buffer = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate); // 1s of silence
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      source.loop = true;
      const gain = ctx.createGain();
      gain.gain.value = 0.0001; // inaudible but a real, continuous media stream
      source.connect(gain).connect(ctx.destination);
      source.start();
      void ctx.resume().catch(() => undefined);
      audioRef.current = {
        ctx,
        stop: () => {
          try {
            source.stop();
          } catch {
            /* ignore */
          }
          void ctx.close().catch(() => undefined);
        },
      };
    } catch {
      /* audio unavailable — other layers still apply */
    }
  }, []);

  const stopSilentAudio = useCallback(() => {
    audioRef.current?.stop();
    audioRef.current = null;
  }, []);

  /* ---------------- Web Worker ---------------- */

  const ensureWorker = useCallback(() => {
    if (workerRef.current) return workerRef.current;
    try {
      const worker = new Worker(new URL("../lib/background/keepalive.worker.ts", import.meta.url), {
        type: "module",
      });
      worker.addEventListener("message", (event: MessageEvent) => {
        const msg = event.data as
          | { type: "beat"; ticks: number }
          | { type: "fetch:ok"; id: string; body: string; status: number }
          | { type: "fetch:err"; id: string };
        if (msg.type === "beat") {
          setBeats(msg.ticks);
          // Ping the service worker on every beat so it is not evicted.
          swRef.current?.postMessage({ type: "KEEPALIVE_PING" });
          return;
        }
        const resolve = pending.current.get(msg.id);
        if (!resolve) return;
        pending.current.delete(msg.id);
        if (msg.type === "fetch:ok") resolve({ ok: msg.status >= 200 && msg.status < 300, body: msg.body });
        else resolve({ ok: false });
      });
      workerRef.current = worker;
      return worker;
    } catch {
      return null;
    }
  }, []);

  const offloadJson = useCallback<BackgroundExecution["offloadJson"]>(
    async (url, body) => {
      const worker = ensureWorker();
      if (!worker) return null;
      const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
      const result = await new Promise<{ ok: boolean; body?: string }>((resolve) => {
        pending.current.set(id, resolve);
        worker.postMessage({
          type: "fetch",
          id,
          url,
          init: { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) },
        });
        setTimeout(() => {
          if (pending.current.delete(id)) resolve({ ok: false });
        }, 180_000);
      });
      if (!result.ok || !result.body) return null;
      try {
        return JSON.parse(result.body) as never;
      } catch {
        return null;
      }
    },
    [ensureWorker],
  );

  /* ---------------- Lock lifecycle ---------------- */

  const begin = useCallback<BackgroundExecution["begin"]>(
    (label) => {
      countRef.current += 1;
      if (countRef.current === 1) {
        setActive(true);
        void acquireWakeLock();
        startSilentAudio();
        ensureWorker()?.postMessage({ type: "start", interval: 1000 });
        if (label) console.info(`[background] holding execution lock for: ${label}`);
      }
      let released = false;
      return () => {
        if (released) return;
        released = true;
        countRef.current = Math.max(0, countRef.current - 1);
        if (countRef.current === 0) {
          setActive(false);
          void releaseWakeLock();
          stopSilentAudio();
          workerRef.current?.postMessage({ type: "stop" });
          setBeats(0);
        }
      };
    },
    [acquireWakeLock, ensureWorker, releaseWakeLock, startSilentAudio, stopSilentAudio],
  );

  const withBackground = useCallback<BackgroundExecution["withBackground"]>(
    async (label, fn) => {
      const release = begin(label);
      try {
        return await fn();
      } finally {
        release();
      }
    },
    [begin],
  );

  useEffect(
    () => () => {
      void releaseWakeLock();
      stopSilentAudio();
      workerRef.current?.terminate();
      workerRef.current = null;
    },
    [releaseWakeLock, stopSilentAudio],
  );

  const value = useMemo<BackgroundExecution>(
    () => ({ active, beats, wakeLock, begin, withBackground, offloadJson }),
    [active, beats, wakeLock, begin, withBackground, offloadJson],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

/** Access the shared background-execution controls. Safe outside the provider (no-ops). */
export function useBackgroundExecution(): BackgroundExecution {
  const ctx = useContext(Ctx);
  return (
    ctx ?? {
      active: false,
      beats: 0,
      wakeLock: false,
      begin: () => () => undefined,
      withBackground: async (_label, fn) => fn(),
      offloadJson: async () => null,
    }
  );
}
