/**
 * useEdgeTTS — modular client-side Microsoft Edge Neural TTS hook.
 *
 * Owns: language/voice-type selection, the resolved Neural Voice ID,
 * WebSocket synthesis, audio playback state (idle | loading | playing |
 * paused), errors and the native-speech fallback.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { EdgeTtsError, edgeTtsSupported, synthesizeWithEdgeTTS } from "@/lib/edge-tts-client";
import {
  localeOf,
  resolveNeuralVoice,
  type TtsLanguage,
  type VoiceType,
} from "@/lib/neural-voices";

export type TtsStatus = "idle" | "loading" | "playing" | "paused";

export type UseEdgeTTSOptions = {
  language?: TtsLanguage;
  voiceType?: VoiceType;
  rate?: string;
  volume?: string;
  /** Allow window.speechSynthesis when the neural socket fails. */
  allowNativeFallback?: boolean;
};

export function useEdgeTTS(options: UseEdgeTTSOptions = {}) {
  const [language, setLanguage] = useState<TtsLanguage>(options.language ?? "bn");
  const [voiceType, setVoiceType] = useState<VoiceType>(options.voiceType ?? "Female");
  const [status, setStatus] = useState<TtsStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const [usedFallback, setUsedFallback] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const urlRef = useRef<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const voiceId = useMemo(() => resolveNeuralVoice(language, voiceType), [language, voiceType]);
  const supported = edgeTtsSupported();

  const releaseUrl = useCallback(() => {
    if (urlRef.current) {
      URL.revokeObjectURL(urlRef.current);
      urlRef.current = null;
    }
  }, []);

  const stop = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    releaseUrl();
    setStatus("idle");
  }, [releaseUrl]);

  useEffect(() => stop, [stop]);

  const nativeFallback = useCallback(
    (text: string) =>
      new Promise<boolean>((resolve) => {
        if (typeof window === "undefined" || !("speechSynthesis" in window)) {
          resolve(false);
          return;
        }
        try {
          window.speechSynthesis.cancel();
          const utter = new SpeechSynthesisUtterance(text);
          utter.lang = localeOf(language);
          utter.onend = () => {
            setStatus("idle");
            resolve(true);
          };
          utter.onerror = () => {
            setStatus("idle");
            resolve(false);
          };
          setStatus("playing");
          window.speechSynthesis.speak(utter);
        } catch {
          setStatus("idle");
          resolve(false);
        }
      }),
    [language],
  );

  const speak = useCallback(
    async (text: string): Promise<boolean> => {
      const value = text.trim();
      if (!value) return false;

      stop();
      setError(null);
      setUsedFallback(false);
      setStatus("loading");

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const blob = await synthesizeWithEdgeTTS({
          text: value,
          voice: voiceId,
          ...(options.rate ? { rate: options.rate } : {}),
          ...(options.volume ? { volume: options.volume } : {}),
          signal: controller.signal,
        });
        if (controller.signal.aborted) return false;

        releaseUrl();
        const url = URL.createObjectURL(blob);
        urlRef.current = url;
        const audio = audioRef.current ?? new Audio();
        audioRef.current = audio;
        audio.src = url;
        audio.onended = () => setStatus("idle");
        audio.onpause = () => setStatus((s) => (s === "playing" ? "paused" : s));
        audio.onplay = () => setStatus("playing");
        await audio.play();
        return true;
      } catch (err) {
        if (controller.signal.aborted) return false;
        const message =
          err instanceof EdgeTtsError ? err.message : `Neural voice unavailable (${String(err)})`;
        setError(message);
        console.warn("[useEdgeTTS]", message);
        if (options.allowNativeFallback !== false) {
          setUsedFallback(true);
          return nativeFallback(value);
        }
        setStatus("idle");
        return false;
      } finally {
        if (abortRef.current === controller) abortRef.current = null;
      }
    },
    [voiceId, options.rate, options.volume, options.allowNativeFallback, stop, releaseUrl, nativeFallback],
  );

  const pause = useCallback(() => {
    if (audioRef.current && !audioRef.current.paused) {
      audioRef.current.pause();
      setStatus("paused");
    } else if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.pause();
      setStatus("paused");
    }
  }, []);

  const resume = useCallback(() => {
    if (audioRef.current?.paused && audioRef.current.src) {
      void audioRef.current.play().catch(() => setStatus("idle"));
      setStatus("playing");
    } else if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.resume();
      setStatus("playing");
    }
  }, []);

  return {
    language,
    setLanguage,
    voiceType,
    setVoiceType,
    voiceId,
    locale: localeOf(language),
    status,
    isLoading: status === "loading",
    isPlaying: status === "playing",
    isPaused: status === "paused",
    error,
    usedFallback,
    supported,
    speak,
    pause,
    resume,
    stop,
  };
}
