import { useCallback, useState } from "react";

import { analyzeAudioCore, type AudioCoreAnalysis } from "@/lib/audio-analyzer";
import { classifySpeaker, type SpeakerProfileType } from "@/lib/dubbingLogicHelpers";

/**
 * MODULE: Pitch & Frequency Analysis (#12)
 * ----------------------------------------
 * Extracts the fundamental frequency (F0) from a decoded AudioBuffer using
 * Meyda.js (spectral) with the existing autocorrelation core as a fallback,
 * then classifies the speaker profile:
 *   Male 80–160Hz · Female 160–250Hz · Child/Teen >250Hz
 *
 * Purely additive: it reuses `analyzeAudioCore` and never mutates player state.
 */

export type PitchProfile = {
  /** Fundamental frequency in Hz (rounded). */
  f0: number;
  /** Male / Female / Child, or Unknown when no voiced pitch was found. */
  profile: SpeakerProfileType | "Unknown";
  /** Ready-to-render tag, e.g. "Male (120Hz)". */
  label: string;
  /** 0–1 confidence proxy derived from spectral flatness / energy. */
  confidence: number;
};

const BUFFER_SIZE = 2048;

function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = sorted.length >> 1;
  return sorted.length % 2 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
}

/** Meyda-based F0 estimate: median of per-frame spectral pitch candidates. */
async function meydaF0(audioBuffer: AudioBuffer): Promise<{ f0: number; confidence: number }> {
  try {
    const Meyda = (await import("meyda")).default as unknown as {
      bufferSize: number;
      sampleRate: number;
      extract: (
        features: string[],
        signal: Float32Array,
      ) => Record<string, number | number[]> | null;
    };
    Meyda.bufferSize = BUFFER_SIZE;
    Meyda.sampleRate = audioBuffer.sampleRate;

    const data = audioBuffer.getChannelData(0);
    const candidates: number[] = [];
    const flatness: number[] = [];
    // Sample at most ~120 frames spread over the clip (cheap + stable).
    const frames = Math.max(1, Math.floor(data.length / BUFFER_SIZE));
    const step = Math.max(1, Math.floor(frames / 120));

    for (let f = 0; f < frames; f += step) {
      const start = f * BUFFER_SIZE;
      const frame = data.slice(start, start + BUFFER_SIZE);
      if (frame.length < BUFFER_SIZE) break;
      let rms = 0;
      for (let i = 0; i < frame.length; i++) rms += frame[i]! * frame[i]!;
      rms = Math.sqrt(rms / frame.length);
      if (rms < 0.01) continue; // silence / unvoiced

      const features = Meyda.extract(["spectralCentroid", "spectralFlatness", "chroma"], frame);
      if (!features) continue;

      const flat = typeof features["spectralFlatness"] === "number" ? features["spectralFlatness"] : 1;
      if (flat > 0.5) continue; // noisy frame, not tonal
      flatness.push(flat);

      // Spectral centroid (bin index) -> Hz, then folded down to the octave
      // that contains human speech F0 (65–400Hz).
      const centroidBin =
        typeof features["spectralCentroid"] === "number" ? features["spectralCentroid"] : 0;
      let hz = (centroidBin * audioBuffer.sampleRate) / BUFFER_SIZE;
      while (hz > 400) hz /= 2;
      if (hz >= 65 && hz <= 400) candidates.push(hz);
    }

    const f0 = median(candidates);
    const confidence = flatness.length
      ? Math.min(1, Math.max(0, 1 - median(flatness)))
      : 0;
    return { f0, confidence };
  } catch {
    return { f0: 0, confidence: 0 };
  }
}

const GENDER_LABEL: Record<SpeakerProfileType, string> = {
  Male: "Male",
  Female: "Female",
  Child: "Child/Teen",
};

export function buildPitchProfile(f0: number, confidence = 0): PitchProfile {
  if (!f0 || f0 <= 0) {
    return { f0: 0, profile: "Unknown", label: "Unknown profile", confidence: 0 };
  }
  const profile = classifySpeaker(f0);
  const hz = Math.round(f0);
  return { f0: hz, profile, label: `${GENDER_LABEL[profile]} (${hz}Hz)`, confidence };
}

export type AudioAnalyzerResult = AudioCoreAnalysis & { pitchProfile: PitchProfile };

/**
 * Analyze an AudioBuffer (or a File) and return the existing core analysis
 * plus the F0-based speaker profile tag.
 */
export function useAudioAnalyzer() {
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState<AudioAnalyzerResult | null>(null);
  const [pitchProfile, setPitchProfile] = useState<PitchProfile | null>(null);

  const analyzeBuffer = useCallback(async (audioBuffer: AudioBuffer) => {
    setAnalyzing(true);
    try {
      const core = await analyzeAudioCore(audioBuffer);
      const { f0, confidence } = await meydaF0(audioBuffer);
      // Meyda estimate first; fall back to the autocorrelation pitch.
      const profile = buildPitchProfile(f0 || core.pitchHz, confidence);
      const full: AudioAnalyzerResult = { ...core, pitchProfile: profile };
      setResult(full);
      setPitchProfile(profile);
      return full;
    } finally {
      setAnalyzing(false);
    }
  }, []);

  const analyzeFile = useCallback(
    async (file: File) => {
      const AudioCtx =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      try {
        const buffer = await ctx.decodeAudioData(await file.arrayBuffer());
        return await analyzeBuffer(buffer);
      } finally {
        void ctx.close();
      }
    },
    [analyzeBuffer],
  );

  const reset = useCallback(() => {
    setResult(null);
    setPitchProfile(null);
  }, []);

  return { analyzing, result, pitchProfile, analyzeBuffer, analyzeFile, reset };
}
