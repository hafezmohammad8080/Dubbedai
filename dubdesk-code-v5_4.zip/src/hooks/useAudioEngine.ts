/**
 * Unified audio engine hook.
 *
 * One place owns: decoding, unique-id clip state (deduplicated), explicit
 * AudioBufferSourceNode cleanup, 30ms exponential sidechain ducking (0% gain
 * during speech overlays) and OfflineAudioContext export.
 *
 * Components stay "preview only" — no manual sliders, no duplicated audio
 * logic. All DSP constants live in `@/lib/overlay`.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import {
  PlaybackEngine,
  audioCtx,
  clipDuration,
  decodeToBuffer,
  dedupeClips,
  detectNonVerbalMoments,
  encodeWavFromBuffer,
  isSameRange,
  renderOverlayMix,
  sliceBuffer,
  uniqueId,
  type OverlayClip,
} from "@/lib/overlay";
import { PRE_BUFFER_MS, preBufferDelay } from "@/lib/engine";

export { PRE_BUFFER_MS };

export type ClipCandidate = { start: number; end: number; label: string };

export type UseAudioEngineArgs = {
  originalFile: File | null;
  dubBlob: Blob | null;
};

export function useAudioEngine({ originalFile, dubBlob }: UseAudioEngineArgs) {
  /** Single PlaybackEngine instance — owns every live BufferSource. */
  const engine = useMemo(() => new PlaybackEngine(), []);

  const [origBuffer, setOrigBuffer] = useState<AudioBuffer | null>(null);
  const [dubBuffer, setDubBuffer] = useState<AudioBuffer | null>(null);
  const [clips, setClips] = useState<OverlayClip[]>([]);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [mixUrl, setMixUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [note, setNote] = useState("");

  const mixUrlRef = useRef<string | null>(null);
  /** Explainer "pause/hold" timer — silence until the next scene timestamp. */
  const holdTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const clearHold = useCallback(() => {
    if (holdTimer.current) clearTimeout(holdTimer.current);
    holdTimer.current = null;
  }, []);

  /* ---------------- buffer / object-url cleanup ---------------- */

  const releaseMix = useCallback(() => {
    if (mixUrlRef.current) URL.revokeObjectURL(mixUrlRef.current);
    mixUrlRef.current = null;
    setMixUrl(null);
  }, []);

  /** Explicit stop() + disconnect() before any new audio is triggered. */
  const stop = useCallback(() => {
    clearHold();
    engine.stopAll();
    setPlayingId(null);
  }, [engine, clearHold]);

  /* ---------------- state deduplication (unique ids) ---------------- */

  const addClips = useCallback(
    (candidates: ClipCandidate[]) => {
      setClips((prev) => {
        const next = [...prev];
        for (const c of candidates) {
          if (c.end - c.start < 0.05) continue;
          if (next.some((k) => isSameRange(k, c))) continue; // duplicate range
          next.push({
            id: uniqueId(next), // strictly unique id, validated against state
            start: c.start,
            end: c.end,
            placeAt: c.start,
            label: c.label,
            enabled: true,
          });
        }
        return dedupeClips(next);
      });
      releaseMix();
    },
    [releaseMix],
  );

  const toggleClip = useCallback(
    (id: string) => {
      setClips((p) => p.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c)));
      releaseMix();
    },
    [releaseMix],
  );

  const removeClip = useCallback(
    (id: string) => {
      setPlayingId((cur) => {
        if (cur === id) engine.stopAll();
        return cur === id ? null : cur;
      });
      setClips((p) => p.filter((c) => c.id !== id));
      releaseMix();
    },
    [engine, releaseMix],
  );

  /* ---------------- decoding ---------------- */

  useEffect(() => {
    engine.stopAll();
    setPlayingId(null);
    setOrigBuffer(null);
    setClips([]);
    releaseMix();
    if (!originalFile) return;
    let live = true;
    decodeToBuffer(originalFile)
      .then((b) => live && setOrigBuffer(b))
      .catch(() => live && setNote("মূল ফাইলটি ডিকোড করা যায়নি।"));
    return () => {
      live = false;
    };
  }, [originalFile, engine, releaseMix]);

  useEffect(() => {
    setDubBuffer(null);
    releaseMix();
    if (!dubBlob) return;
    let live = true;
    decodeToBuffer(dubBlob)
      .then((b) => live && setDubBuffer(b))
      .catch(() => live && setNote("ডাব ট্র্যাক ডিকোড করা যায়নি।"));
    return () => {
      live = false;
    };
  }, [dubBlob, releaseMix]);

  /** Unmount: stop nodes, free buffers, revoke urls. */
  useEffect(
    () => () => {
      if (holdTimer.current) clearTimeout(holdTimer.current);
      engine.stopAll();
      if (mixUrlRef.current) URL.revokeObjectURL(mixUrlRef.current);
    },
    [engine],
  );

  /* ---------------- detection ---------------- */

  const detect = useCallback(async () => {
    if (!origBuffer) return;
    stop();
    setBusy("ভোকাল ফ্রিকোয়েন্সি স্ক্যান হচ্ছে…");
    try {
      const events = await detectNonVerbalMoments(origBuffer);
      if (!events.length) {
        setNote("মানুষের ভয়েস রেঞ্জে (৩০০Hz–৩kHz) কোনো নন-ভার্বাল মুহূর্ত পাওয়া যায়নি।");
        return;
      }
      addClips(events.map((e) => ({ start: e.start, end: e.end, label: "নন-ভার্বাল মুহূর্ত" })));
      setNote(`${events.length}টি মুহূর্ত পাওয়া গেছে (বাদ্যযন্ত্রের শব্দ বাদ)।`);
    } catch {
      setNote("ডিটেকশন ব্যর্থ হয়েছে।");
    } finally {
      setBusy(null);
    }
  }, [origBuffer, addClips, stop]);

  /* ---------------- preview playback ---------------- */

  /** Toggle-preview a single clip. Always cleans up the previous source. */
  const previewClip = useCallback(
    async (clip: OverlayClip, isExplainerMode?: boolean) => {
      if (!origBuffer) return;
      if (playingId === clip.id) {
        stop();
        return;
      }
      stop(); // buffer cleanup before triggering new audio
      void audioCtx().resume();
      const buffer = sliceBuffer(origBuffer, clip.start, clip.end);
      setPlayingId(clip.id);
      // Pre-buffer (50–100ms): buffers ready before the first sample plays,
      // which removes the click/pop ("tang tang") noise and clip overlap.
      await preBufferDelay();
      if (isExplainerMode === true) {
        // EXPLAINER: natural 1.0x rate, no time-stretching. If the audio ends
        // before the scene window does, hold silence until the scene's end.
        const sceneDur = Math.max(0, clip.end - clip.start);
        engine.play(buffer, () => {
          const remaining = sceneDur - buffer.duration;
          if (remaining > 0.01) {
            clearHold();
            holdTimer.current = setTimeout(() => setPlayingId(null), remaining * 1000);
          } else {
            setPlayingId(null);
          }
        });
        return;
      }
      // DUBBING: original behaviour, untouched.
      engine.play(buffer, () => setPlayingId(null));
    },
    [origBuffer, playingId, engine, stop, clearHold],
  );

  /** Preview the ducked mix (dub at 0% under every enabled clip). */
  const previewMix = useCallback(async (isExplainerMode?: boolean) => {
    if (!origBuffer || !dubBuffer) return;
    if (playingId === "mix") {
      stop();
      return;
    }
    stop();
    setBusy("প্রিভিউ তৈরি হচ্ছে…");
    try {
      const rendered = await renderOverlayMix({ dub: dubBuffer, original: origBuffer, clips });
      void audioCtx().resume();
      setPlayingId("mix");
      // Pre-buffer before the mix starts — prevents the initial pop.
      await preBufferDelay();
      // Explainer mode plays at natural rate; the mix itself is never
      // time-stretched here, so both branches share this playback path.
      void isExplainerMode;
      engine.play(rendered, () => setPlayingId(null));
    } catch {
      setNote("প্রিভিউ ব্যর্থ হয়েছে।");
    } finally {
      setBusy(null);
    }
  }, [origBuffer, dubBuffer, clips, playingId, engine, stop]);

  /* ---------------- in-browser export ---------------- */

  const exportMix = useCallback(async () => {
    if (!origBuffer || !dubBuffer) return;
    stop();
    releaseMix();
    setBusy("এক্সপোর্ট হচ্ছে…");
    try {
      const rendered = await renderOverlayMix({ dub: dubBuffer, original: origBuffer, clips });
      const url = URL.createObjectURL(encodeWavFromBuffer(rendered));
      mixUrlRef.current = url;
      setMixUrl(url);
      setNote("এক্সপোর্ট সম্পন্ন — নিচ থেকে ডাউনলোড করুন।");
    } catch (err) {
      setNote(`এক্সপোর্ট ব্যর্থ: ${err instanceof Error ? err.message : "unknown"}`);
    } finally {
      setBusy(null);
    }
  }, [origBuffer, dubBuffer, clips, stop, releaseMix]);

  const activeCount = clips.filter((c) => c.enabled).length;

  return {
    origBuffer,
    dubBuffer,
    clips,
    activeCount,
    playingId,
    busy,
    note,
    mixUrl,
    ready: Boolean(origBuffer && dubBuffer),
    addClips,
    toggleClip,
    removeClip,
    detect,
    previewClip,
    previewMix,
    exportMix,
    stop,
    clipDuration,
  };
}

export type AudioEngine = ReturnType<typeof useAudioEngine>;
