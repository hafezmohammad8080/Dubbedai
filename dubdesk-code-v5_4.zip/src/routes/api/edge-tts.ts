/**
 * Same-origin fallback for the Edge Neural TTS WebSocket.
 *
 * Browsers cannot set the Origin / User-Agent headers Microsoft's readaloud
 * endpoint requires, so a direct in-page WSS handshake is rejected. This route
 * performs the identical handshake with the right headers and returns the MP3.
 * The client still tries the direct socket first; this is only the fallback.
 */

import { createFileRoute } from "@tanstack/react-router";

const TRUSTED_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
const ENDPOINT =
  "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1";
const SEC_MS_GEC_VERSION = "1-130.0.2849.68";
const OUTPUT_FORMAT = "audio-24khz-48kbitrate-mono-mp3";
const WIN_EPOCH_OFFSET_SEC = 11_644_473_600;
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0";
const ORIGIN = "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold";

function escapeXml(v: string): string {
  return v
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function hex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function secMsGec(): Promise<string> {
  let ticks = Math.floor((Date.now() / 1000 + WIN_EPOCH_OFFSET_SEC) * 1e7);
  ticks -= ticks % 3_000_000_000;
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${ticks}${TRUSTED_TOKEN}`),
  );
  return hex(digest).toUpperCase();
}

function randomId(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return hex(bytes.buffer);
}

function audioPayload(buffer: ArrayBuffer): Uint8Array | null {
  if (buffer.byteLength < 2) return null;
  const headerLength = new DataView(buffer).getUint16(0, false);
  if (buffer.byteLength <= headerLength + 2) return null;
  const header = new TextDecoder().decode(new Uint8Array(buffer, 2, headerLength));
  if (!/Path:\s*audio/i.test(header)) return null;
  return new Uint8Array(buffer, headerLength + 2);
}

/**
 * Never hard-fail: a 200 + JSON marker tells the client to degrade to the
 * system voice instead of surfacing a runtime error / blank screen.
 */
function unavailable(reason: string): Response {
  console.warn("[api/edge-tts]", reason);
  return new Response(JSON.stringify({ fallback: "browser", reason }), {
    status: 200,
    headers: {
      "Content-Type": "application/json",
      "X-TTS-Source": "browser",
      "Cache-Control": "no-store",
    },
  });
}

export const Route = createFileRoute("/api/edge-tts")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: {
          text?: string;
          voice?: string;
          rate?: string;
          volume?: string;
          pitch?: string;
        };
        try {
          body = await request.json();
        } catch {
          return new Response("Invalid JSON body", { status: 400 });
        }

        const text = (body.text ?? "").trim();
        const voice = (body.voice ?? "").trim();
        if (!text || !voice) return new Response("text and voice are required", { status: 400 });

        const lang = voice.split("-").slice(0, 2).join("-") || "en-US";
        const ssml =
          `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="${lang}">` +
          `<voice name="${voice}"><prosody pitch="${body.pitch ?? "+0Hz"}" rate="${
            body.rate ?? "+0%"
          }" volume="${body.volume ?? "+0%"}">${escapeXml(text)}</prosody></voice></speak>`;

        const url =
          `${ENDPOINT}?TrustedClientToken=${TRUSTED_TOKEN}` +
          `&Sec-MS-GEC=${await secMsGec()}&Sec-MS-GEC-Version=${SEC_MS_GEC_VERSION}` +
          `&ConnectionId=${randomId()}`;

        let socket: WebSocket;
        try {
          const upstream = await fetch(url.replace(/^wss:/, "https:"), {
            headers: {
              Upgrade: "websocket",
              Connection: "Upgrade",
              Origin: ORIGIN,
              "User-Agent": UA,
              Pragma: "no-cache",
              "Cache-Control": "no-cache",
            },
          });
          const ws = (upstream as unknown as { webSocket?: WebSocket }).webSocket;
          if (!ws) {
            return unavailable(`Upstream refused websocket (${upstream.status})`);
          }
          socket = ws;
          (socket as unknown as { accept: () => void }).accept();
        } catch (err) {
          return unavailable(`TTS upstream error: ${String(err)}`);
        }

        const chunks: Uint8Array[] = [];
        const audio = await new Promise<Uint8Array[] | null>((resolve) => {
          const timer = setTimeout(() => {
            try {
              socket.close();
            } catch {
              /* ignore */
            }
            resolve(chunks.length ? chunks : null);
          }, 25000);

          const done = (ok: boolean) => {
            clearTimeout(timer);
            try {
              socket.close();
            } catch {
              /* ignore */
            }
            resolve(ok && chunks.length ? chunks : null);
          };

          socket.addEventListener("message", (event: MessageEvent) => {
            const data = event.data;
            if (typeof data === "string") {
              if (/Path:\s*turn\.end/i.test(data)) done(true);
              return;
            }
            const payload = audioPayload(data as ArrayBuffer);
            if (payload) chunks.push(payload);
          });
          socket.addEventListener("error", () => done(false));
          socket.addEventListener("close", () => done(true));

          const stamp = new Date().toISOString();
          socket.send(
            `X-Timestamp:${stamp}\r\nContent-Type:application/json; charset=utf-8\r\n` +
              `Path:speech.config\r\n\r\n` +
              JSON.stringify({
                context: {
                  synthesis: {
                    audio: {
                      metadataoptions: {
                        sentenceBoundaryEnabled: false,
                        wordBoundaryEnabled: false,
                      },
                      outputFormat: OUTPUT_FORMAT,
                    },
                  },
                },
              }),
          );
          socket.send(
            `X-RequestId:${randomId()}\r\nContent-Type:application/ssml+xml\r\n` +
              `X-Timestamp:${stamp}Z\r\nPath:ssml\r\n\r\n${ssml}`,
          );
        });

        if (!audio) return unavailable("No audio returned");

        const total = audio.reduce((n, c) => n + c.byteLength, 0);
        const merged = new Uint8Array(total);
        let offset = 0;
        for (const c of audio) {
          merged.set(c, offset);
          offset += c.byteLength;
        }

        return new Response(merged, {
          headers: {
            "Content-Type": "audio/mpeg",
            "X-TTS-Source": "edge-neural",
            "Cache-Control": "no-store",
          },
        });
      },
    },
  },
});
