import { createFileRoute } from "@tanstack/react-router";
import { routeGenerate } from "@/lib/model-engine.server";

// POST /api/generate — open pipeline bridge to the Model Routing Engine.
// Body: { "mode": "fast" | "slow", "prompt": "...", "system_instruction": "..." }
export const Route = createFileRoute("/api/generate")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        let body: Record<string, unknown>;
        try {
          body = await request.json();
        } catch {
          return new Response("Invalid JSON body", { status: 400 });
        }

        const result = await routeGenerate({
          mode: body["mode"],
          prompt: body["prompt"],
          systemInstruction: body["system_instruction"] ?? body["systemInstruction"],
        });

        return new Response(JSON.stringify(result), {
          status: result.status === "success" ? 200 : 502,
          headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
        });
      },
    },
  },
});
