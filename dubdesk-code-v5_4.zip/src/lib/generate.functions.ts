import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { routeGenerate } from "./model-engine.server";
import {
  rewriteAndDetectEmotion,
  translateSubtitles,
  MOODS,
} from "./script-engine.server";

const GenerateInput = z.object({
  mode: z.enum(["fast", "slow"]).default("fast"),
  prompt: z.string().min(1),
  systemInstruction: z.string().optional(),
});

export const generateWithMode = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => GenerateInput.parse(d))
  .handler(async ({ data }) =>
    routeGenerate({
      mode: data.mode,
      prompt: data.prompt,
      systemInstruction: data.systemInstruction,
    }),
  );

const SceneInput = z.object({
  startTime: z.string(),
  endTime: z.string(),
  originalText: z.string().min(1),
});

const RewriteInput = z.object({
  sourceLanguage: z.string().default("English"),
  targetLanguage: z.string().min(1),
  voicePersona: z.string().default("Male YouTuber"),
  scenes: z.array(SceneInput).min(1),
  mode: z.enum(["fast", "slow"]).default("fast"),
});

export const rewriteScriptWithEmotion = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => RewriteInput.parse(d))
  .handler(async ({ data }) => {
    const payload = await rewriteAndDetectEmotion(data);
    return {
      status: "success" as const,
      targetLanguage: payload.targetLanguage,
      moods: MOODS,
      scenes: payload.scenes.map((s, i) => ({
        id: i,
        startTime: s.startTime,
        endTime: s.endTime,
        originalText: s.originalText,
        rewrittenText: s.rewrittenText ?? s.originalText,
        detectedMood: s.detectedMood ?? "neutral",
      })),
    };
  });

const SubtitleInput = z.object({
  subtitles: z
    .array(
      z.object({
        id: z.number(),
        start: z.string(),
        end: z.string(),
        text: z.string().min(1),
      }),
    )
    .min(1),
  targetLanguage: z.string().default("Bengali"),
  mode: z.enum(["fast", "slow"]).default("slow"),
});

export const translateSubtitleBlocks = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => SubtitleInput.parse(d))
  .handler(async ({ data }) =>
    translateSubtitles(data.subtitles, data.targetLanguage, data.mode),
  );
