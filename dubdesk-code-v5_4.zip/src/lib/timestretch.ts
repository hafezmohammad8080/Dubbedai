/**
 * Pitch-preserving time stretching (WSOLA), pure browser JS.
 *
 * Used so a generated dubbing clip can be squeezed or stretched to fit the
 * exact duration of the original line WITHOUT making the voice sound thin
 * (chipmunk) or thick (slowed down). No server, no library.
 */

/** Clamp helper so we never destroy intelligibility. */
export const clampRate = (rate: number, min = 0.7, max = 1.7) =>
  Math.max(min, Math.min(max, rate));

/**
 * Stretch mono PCM by `rate` (output length = input length / rate).
 * rate > 1 => faster/shorter, rate < 1 => slower/longer. Pitch is preserved.
 */
export function wsolaStretch(input: Float32Array, sampleRate: number, rate: number): Float32Array {
  if (!input.length) return input;
  const r = clampRate(rate);
  if (Math.abs(r - 1) < 0.02) return input;

  const frame = Math.max(256, Math.round(sampleRate * 0.06)); // ~60ms
  const half = Math.floor(frame / 2);
  const synHop = half; // 50% overlap
  const anaHop = Math.max(1, Math.round(synHop * r));
  const search = Math.max(8, Math.round(sampleRate * 0.01)); // ±10ms

  const outLen = Math.max(frame, Math.ceil(input.length / r) + frame);
  const out = new Float32Array(outLen);
  const norm = new Float32Array(outLen);

  // Hann window
  const win = new Float32Array(frame);
  for (let i = 0; i < frame; i++) win[i] = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (frame - 1));

  let anaPos = 0;
  let outPos = 0;
  let prevTailStart = 0; // position in input of the samples we last wrote at the overlap

  while (anaPos + frame < input.length && outPos + frame < outLen) {
    // Find the input offset (within ±search) whose head best matches what is
    // already written in the overlap region — this keeps waveforms in phase.
    let best = anaPos;
    if (outPos > 0) {
      let bestScore = -Infinity;
      const lo = Math.max(0, anaPos - search);
      const hi = Math.min(input.length - frame - 1, anaPos + search);
      for (let cand = lo; cand <= hi; cand++) {
        let score = 0;
        for (let i = 0; i < half; i += 4) {
          score += (input[cand + i] ?? 0) * (input[prevTailStart + synHop + i] ?? 0);
        }
        if (score > bestScore) {
          bestScore = score;
          best = cand;
        }
      }
    }

    for (let i = 0; i < frame; i++) {
      const w = win[i]!;
      out[outPos + i] = (out[outPos + i] ?? 0) + (input[best + i] ?? 0) * w;
      norm[outPos + i] = (norm[outPos + i] ?? 0) + w;
    }

    prevTailStart = best;
    outPos += synHop;
    anaPos += anaHop;
  }

  const finalLen = Math.max(1, Math.min(outLen, outPos + frame));
  const result = new Float32Array(finalLen);
  for (let i = 0; i < finalLen; i++) {
    const n = norm[i] ?? 0;
    result[i] = n > 1e-4 ? (out[i] ?? 0) / n : (out[i] ?? 0);
  }
  return result;
}

/** Stretch a decoded AudioBuffer so it lasts exactly `targetSec` (best effort). */
export function fitBufferToDuration(
  buffer: AudioBuffer,
  targetSec: number,
  ctxFactory: (channels: number, length: number, rate: number) => AudioBuffer,
): AudioBuffer {
  if (!(targetSec > 0.05) || buffer.duration <= 0) return buffer;
  const rate = clampRate(buffer.duration / targetSec);
  if (Math.abs(rate - 1) < 0.02) return buffer;

  const channels = buffer.numberOfChannels;
  const stretched: Float32Array[] = [];
  for (let c = 0; c < channels; c++) {
    stretched.push(wsolaStretch(buffer.getChannelData(c).slice(), buffer.sampleRate, rate));
  }
  const len = Math.max(1, stretched[0]!.length);
  const out = ctxFactory(channels, len, buffer.sampleRate);
  for (let c = 0; c < channels; c++) {
    const data = new Float32Array(len);
    data.set(stretched[c]!.subarray(0, len));
    out.copyToChannel(data, c);
  }
  return out;
}
