/**
 * Key-free translation fallbacks.
 *
 * Used whenever no provider API key is configured, or when the configured
 * provider fails (error, quota, 429 rate limit). These endpoints need no
 * credentials, so the dubbing pipeline can always continue.
 */

import { resilientFetch, textQueue } from "@/lib/net";

export type FallbackLang = string;

const MYMEMORY = "https://api.mymemory.translated.net/get";
const LIBRETRANSLATE_ENDPOINTS = [
  "https://translate.disroot.org/translate",
  "https://libretranslate.de/translate",
];

/** MyMemory caps a single request at ~500 chars, so translate in slices. */
function splitText(text: string, limit = 450): string[] {
  const parts: string[] = [];
  let rest = text.trim();
  while (rest.length > limit) {
    const window = rest.slice(0, limit);
    const cut = Math.max(window.lastIndexOf("। "), window.lastIndexOf(". "), window.lastIndexOf(" "));
    const at = cut > 40 ? cut + 1 : limit;
    parts.push(rest.slice(0, at).trim());
    rest = rest.slice(at).trim();
  }
  if (rest) parts.push(rest);
  return parts;
}

async function myMemory(text: string, source: string, target: string): Promise<string> {
  const out: string[] = [];
  for (const part of splitText(text)) {
    const url = `${MYMEMORY}?q=${encodeURIComponent(part)}&langpair=${source}|${target}`;
    const res = await textQueue.add(() =>
      resilientFetch(url, {}, { label: "mymemory", retries: 2, baseDelayMs: 1000 }),
    );
    const json = (await res.json()) as { responseData?: { translatedText?: string } };
    const t = json.responseData?.translatedText;
    if (!t) throw new Error("MyMemory returned no text");
    out.push(t);
  }
  return out.join(" ");
}

async function libreTranslate(text: string, source: string, target: string): Promise<string> {
  let lastError: unknown;
  for (const endpoint of LIBRETRANSLATE_ENDPOINTS) {
    try {
      const res = await textQueue.add(() =>
        resilientFetch(
          endpoint,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ q: text, source, target, format: "text" }),
          },
          { label: "libretranslate", retries: 2, baseDelayMs: 1000 },
        ),
      );
      const json = (await res.json()) as { translatedText?: string };
      if (!json.translatedText) throw new Error("LibreTranslate returned no text");
      return json.translatedText;
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("LibreTranslate unavailable");
}

/**
 * Translate with free public endpoints. Never throws — if every endpoint is
 * unreachable the original text is returned so the pipeline keeps running.
 */
export async function translateFree(
  text: string,
  target: FallbackLang = "bn",
  source: FallbackLang = "auto",
): Promise<string> {
  const clean = text.trim();
  if (!clean) return text;
  const src = source === "auto" ? "en" : source;
  for (const attempt of [myMemory, libreTranslate]) {
    try {
      const result = await attempt(clean, src, target);
      if (result.trim()) return result;
    } catch (err) {
      console.warn("[translate-fallback] endpoint failed:", err);
    }
  }
  // Local last-resort fallback: keep the original text rather than halting.
  return text;
}
