// Script Rewrite & Emotion Detection Engine + Timestamped Subtitle
// Translation Engine (server-side core).
//
// Pipeline contract: subtitle transcript blocks in -> natural storyteller
// rewrite + per-scene mood taxonomy out, with timestamps untouched.

import { chatComplete, MODE_CONFIGS, resolveMode, type ProcessingMode } from "./model-engine.server";

export const MOODS = ["action", "sad", "romantic", "suspense", "happy", "neutral"] as const;
export type Mood = (typeof MOODS)[number];

export interface SceneBlock {
  startTime: string;
  endTime: string;
  originalText: string;
  rewrittenText?: string;
  detectedMood?: Mood;
}

export interface PipelinePayload {
  sourceLanguage: string;
  targetLanguage: string;
  voicePersona: string; // e.g. "Male YouTuber", "Female Storyteller"
  scenes: SceneBlock[];
  mode?: ProcessingMode;
  metadata?: Record<string, unknown>;
}

const REWRITE_SYSTEM =
  "You are an expert YouTube Explainer and Storyteller scriptwriter. " +
  "Your task is to rewrite raw video transcripts into a highly engaging, " +
  "natural human-like storytelling script while maintaining exact timestamp alignments. " +
  "You must output pure valid JSON matching the requested schema.";

export async function rewriteAndDetectEmotion(payload: PipelinePayload): Promise<PipelinePayload> {
  const mode = resolveMode(payload.mode);
  const config = MODE_CONFIGS[mode];

  const scenesData = payload.scenes.map((s, idx) => ({
    id: idx,
    timestamp: `[${s.startTime} - ${s.endTime}]`,
    text: s.originalText,
  }));

  const prompt = `Target Language: ${payload.targetLanguage}
Voice Persona Style: ${payload.voicePersona}

Input Subtitle Blocks:
${JSON.stringify(scenesData, null, 2)}

Instructions:
1. Rewrite the transcript for each block into natural spoken storytelling dialect in ${payload.targetLanguage}.
2. Keep sentences fluent, emotionally resonant, and formatted for human speech delivery (avoid robotic translations).
3. Inject natural spoken pauses contextually using standard punctuation (, for short pause, . for long pause).
4. Do NOT merge, split, or drop scene timestamp windows; keep sentence length relative to the scene window.
5. Analyze the context of each block and assign exactly one detected_mood from: ['action', 'sad', 'romantic', 'suspense', 'happy', 'neutral'].

Respond STRICTLY with a JSON array of objects with keys: "id", "rewritten_text", "detected_mood". Wrap the array in an object: {"scenes": [...]}.`;

  try {
    const raw = await chatComplete({
      model: config.modelName,
      temperature: config.temperature,
      jsonMode: true,
      messages: [
        { role: "system", content: REWRITE_SYSTEM },
        { role: "user", content: prompt },
      ],
    });

    const parsed = JSON.parse(raw) as { scenes?: unknown[] } | unknown[];
    const results = Array.isArray(parsed) ? parsed : (parsed.scenes ?? []);
    const resultMap = new Map<number, { rewritten_text?: unknown; detected_mood?: unknown }>();
    for (const item of results as Array<Record<string, unknown>>) {
      if (typeof item?.["id"] === "number") resultMap.set(item["id"], item);
    }

    payload.scenes.forEach((scene, idx) => {
      const r = resultMap.get(idx);
      const mood = typeof r?.detected_mood === "string" ? r.detected_mood : "neutral";
      scene.rewrittenText =
        typeof r?.rewritten_text === "string" && r.rewritten_text.trim()
          ? r.rewritten_text
          : scene.originalText;
      scene.detectedMood = (MOODS as readonly string[]).includes(mood) ? (mood as Mood) : "neutral";
    });

    return payload;
  } catch (err) {
    // Fallback: never break the pipeline — keep original text untouched.
    console.error("[script-engine] rewrite failed:", err);
    for (const scene of payload.scenes) {
      if (!scene.rewrittenText) scene.rewrittenText = scene.originalText;
      if (!scene.detectedMood) scene.detectedMood = "neutral";
    }
    return payload;
  }
}

export interface SubtitleBlock {
  id: number;
  start: string;
  end: string;
  text: string;
}

export interface TranslatedSubtitle {
  id: number;
  start: string;
  end: string;
  translated_text: string;
}

const TRANSLATE_SYSTEM =
  "You are a professional video subtitle translator. " +
  "Translate the text blocks accurately to the target language without altering " +
  "the timing context, technical terms, or structural metadata.";

export async function translateSubtitles(
  subtitles: SubtitleBlock[],
  targetLanguage = "Bengali",
  mode?: ProcessingMode,
): Promise<TranslatedSubtitle[]> {
  if (!subtitles.length) return [];

  const config = MODE_CONFIGS[resolveMode(mode)];

  const prompt = `Target Language: ${targetLanguage}

Input Subtitles:
${JSON.stringify(subtitles, null, 2)}

Translate the 'text' field of each object into pure, accurate ${targetLanguage}.
Do not merge or delete timestamp keys.

Return STRICTLY a JSON array of objects with keys: "id", "start", "end", "translated_text".
Wrap the array in an object: {"subtitles": [...]}.`;

  try {
    const raw = await chatComplete({
      model: config.modelName,
      temperature: Math.min(config.temperature, 0.3), // accuracy for translation
      jsonMode: true,
      messages: [
        { role: "system", content: TRANSLATE_SYSTEM },
        { role: "user", content: prompt },
      ],
    });

    const parsed = JSON.parse(raw) as { subtitles?: unknown[] } | unknown[];
    const results = Array.isArray(parsed) ? parsed : (parsed.subtitles ?? []);

    const out: TranslatedSubtitle[] = [];
    for (const item of results as Array<Record<string, unknown>>) {
      const src = subtitles.find((s) => s.id === item?.["id"]);
      if (!src) continue;
      const tStart = item["start"];
      const tEnd = item["end"];
      const tText = item["translated_text"];
      out.push({
        id: src.id,
        start: typeof tStart === "string" ? tStart : src.start,
        end: typeof tEnd === "string" ? tEnd : src.end,
        translated_text:
          typeof tText === "string" && tText.trim() ? tText : src.text,
      });
    }
    return out.length ? out : fallbackTranslation(subtitles);
  } catch (err) {
    console.error("[script-engine] translation failed:", err);
    return fallbackTranslation(subtitles);
  }
}

function fallbackTranslation(subtitles: SubtitleBlock[]): TranslatedSubtitle[] {
  return subtitles.map((s) => ({ id: s.id, start: s.start, end: s.end, translated_text: s.text }));
}
