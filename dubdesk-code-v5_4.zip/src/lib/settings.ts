/**
 * Shared settings helpers + types.
 *
 * API keys and the model preference are stored in the browser's
 * localStorage so they persist across sessions. Keys are kept in plain
 * localStorage (browser-side only); never expose them to the server
 * unless explicitly required.
 *
 * MODULE 4: every read/write is null/undefined/empty-string safe, and an
 * in-memory cache is kept in sync so deleting a key purges it instantly and
 * the app drops to Default Free Mode without a page refresh.
 */

export type AiModel = "auto" | "gemini" | "groq" | "free";

export const STORAGE_KEYS = {
  gemini: "gemini_key",
  groq: "groq_key",
  tts: "tts_key",
  model: "ai_model",
} as const;

export const SETTINGS_EVENT = "dubdesk:settings-changed";

export const MODEL_OPTIONS: { value: AiModel; label: string; hint: string }[] = [
  {
    value: "auto",
    label: "Auto",
    hint: "Uses your key if present, otherwise the free translation fallback",
  },
  { value: "gemini", label: "Gemini", hint: "Google Gemini (falls back if it fails)" },
  { value: "groq", label: "Groq", hint: "Groq ultra-fast inference (falls back if it fails)" },
  { value: "free", label: "Free (no key)", hint: "Public translation endpoints — no API key needed" },
];

export interface AppSettings {
  geminiKey: string;
  groqKey: string;
  ttsKey: string;
  model: AiModel;
}

export const DEFAULT_SETTINGS: AppSettings = {
  geminiKey: "",
  groqKey: "",
  ttsKey: "",
  model: "auto",
};

/** Coerce anything (null / undefined / "  " / non-string) to a clean string. */
export function sanitizeKey(value: unknown): string {
  if (typeof value !== "string") return "";
  const trimmed = value.trim();
  if (!trimmed || trimmed === "null" || trimmed === "undefined") return "";
  return trimmed;
}

export function sanitizeModel(value: unknown): AiModel {
  return value === "gemini" || value === "groq" || value === "free" || value === "auto"
    ? value
    : DEFAULT_SETTINGS.model;
}

/** In-memory mirror so consumers never read a stale key after a delete. */
let cache: AppSettings | null = null;

function readRaw(key: string): string {
  if (typeof window === "undefined") return "";
  try {
    return sanitizeKey(localStorage.getItem(key));
  } catch {
    return "";
  }
}

/** Read the current settings (browser-only, cached, always well-formed). */
export function loadSettings(): AppSettings {
  if (typeof window === "undefined") return { ...DEFAULT_SETTINGS };
  if (cache) return { ...cache };
  cache = {
    geminiKey: readRaw(STORAGE_KEYS.gemini),
    groqKey: readRaw(STORAGE_KEYS.groq),
    ttsKey: readRaw(STORAGE_KEYS.tts),
    model: sanitizeModel(readRaw(STORAGE_KEYS.model) || DEFAULT_SETTINGS.model),
  };
  return { ...cache };
}

function notify(settings: AppSettings) {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent<AppSettings>(SETTINGS_EVENT, { detail: settings }));
}

/** Persist settings. Empty / null values are removed rather than stored. */
export function saveSettings(input: Partial<AppSettings>): AppSettings {
  const next: AppSettings = {
    geminiKey: sanitizeKey(input.geminiKey),
    groqKey: sanitizeKey(input.groqKey),
    ttsKey: sanitizeKey(input.ttsKey),
    model: sanitizeModel(input.model),
  };
  cache = next;
  if (typeof window !== "undefined") {
    try {
      const write = (key: string, value: string) =>
        value ? localStorage.setItem(key, value) : localStorage.removeItem(key);
      write(STORAGE_KEYS.gemini, next.geminiKey);
      write(STORAGE_KEYS.groq, next.groqKey);
      write(STORAGE_KEYS.tts, next.ttsKey);
      localStorage.setItem(STORAGE_KEYS.model, next.model);
    } catch (err) {
      console.warn("[settings] could not persist settings:", err);
    }
  }
  notify(next);
  return next;
}

/** Purge one key from storage AND memory immediately (no refresh needed). */
export function purgeKey(field: "geminiKey" | "groqKey" | "ttsKey"): AppSettings {
  const current = loadSettings();
  return saveSettings({ ...current, [field]: "" });
}

/** Clear everything and return to Default Free Mode instantly. */
export function clearSettings(): AppSettings {
  cache = { ...DEFAULT_SETTINGS };
  if (typeof window !== "undefined") {
    try {
      Object.values(STORAGE_KEYS).forEach((key) => localStorage.removeItem(key));
    } catch (err) {
      console.warn("[settings] could not clear settings:", err);
    }
  }
  notify({ ...DEFAULT_SETTINGS });
  return { ...DEFAULT_SETTINGS };
}

/** True when no provider key is configured → free/system fallback mode. */
export function isFreeMode(settings: AppSettings = loadSettings()): boolean {
  return settings.model === "free" || (!settings.geminiKey && !settings.groqKey);
}

/** Subscribe to live settings changes (same tab + other tabs). */
export function subscribeSettings(listener: (s: AppSettings) => void): () => void {
  if (typeof window === "undefined") return () => {};
  const onCustom = (e: Event) => listener((e as CustomEvent<AppSettings>).detail);
  const onStorage = () => {
    cache = null;
    listener(loadSettings());
  };
  window.addEventListener(SETTINGS_EVENT, onCustom);
  window.addEventListener("storage", onStorage);
  return () => {
    window.removeEventListener(SETTINGS_EVENT, onCustom);
    window.removeEventListener("storage", onStorage);
  };
}
