export type CategoryId =
  | "adult_male"
  | "adult_female"
  | "elderly_male"
  | "elderly_female"
  | "young_boy"
  | "young_girl"
  | "teen_boy"
  | "teen_girl";

export type Voice = {
  id: string;
  name: string;
  /** Gemini TTS prebuilt voice name */
  engineVoice: string;
  category: CategoryId;
  /** ভারী / স্বাভাবিক / হালকা */
  tone: string;
  /** Persona instruction prefixed to every utterance so age + gender stay locked. */
  persona: string;
};

export type Category = {
  id: CategoryId;
  label: string;
  ageLabel: string;
  gender: "male" | "female";
};

export const CATEGORIES: Category[] = [
  { id: "adult_male", label: "প্রাপ্তবয়স্ক পুরুষ", ageLabel: "২৩–৪৫ বছর", gender: "male" },
  { id: "adult_female", label: "প্রাপ্তবয়স্ক মহিলা", ageLabel: "২৩–৪৫ বছর", gender: "female" },
  { id: "elderly_male", label: "বয়স্ক পুরুষ", ageLabel: "৪৫+ বছর", gender: "male" },
  { id: "elderly_female", label: "বয়স্ক মহিলা", ageLabel: "৪৫+ বছর", gender: "female" },
  { id: "young_boy", label: "ছোট ছেলে", ageLabel: "১২ বছরের কম", gender: "male" },
  { id: "young_girl", label: "ছোট মেয়ে", ageLabel: "১২ বছরের কম", gender: "female" },
  { id: "teen_boy", label: "কিশোর ছেলে", ageLabel: "১৩–২২ বছর", gender: "male" },
  { id: "teen_girl", label: "কিশোরী মেয়ে", ageLabel: "১৩–২২ বছর", gender: "female" },
];

const MALE_CORE =
  "You are a MALE speaker. Keep a clearly masculine chest-resonant timbre at all times — never drift into a feminine or androgynous pitch.";
const FEMALE_CORE =
  "You are a FEMALE speaker. Keep a clearly feminine, higher-placed head-resonant timbre at all times — never drift into a masculine or androgynous pitch.";

export const VOICES: Voice[] = [
  // ---------- Adult male (23-45) ----------
  {
    id: "am_heavy",
    name: "রুদ্র",
    engineVoice: "Charon",
    category: "adult_male",
    tone: "ভারী",
    persona: `${MALE_CORE} Age about 40. Deep, heavy, gravelly baritone with slow confident weight.`,
  },
  {
    id: "am_normal",
    name: "আরিয়ান",
    engineVoice: "Orus",
    category: "adult_male",
    tone: "স্বাভাবিক",
    persona: `${MALE_CORE} Age about 30. Warm everyday conversational male voice, relaxed and natural.`,
  },
  {
    id: "am_light",
    name: "সাহিল",
    engineVoice: "Puck",
    category: "adult_male",
    tone: "হালকা",
    persona: `${MALE_CORE} Age about 25. Bright, light, quick-witted young-adult male voice with playful lift.`,
  },
  {
    id: "am_grit",
    name: "কায়েস",
    engineVoice: "Algenib",
    category: "adult_male",
    tone: "খসখসে",
    persona: `${MALE_CORE} Age about 38. Rough, smoky, slightly raspy male voice with street-real edge.`,
  },

  // ---------- Adult female (23-45) ----------
  {
    id: "af_heavy",
    name: "নাবিলা",
    engineVoice: "Sulafat",
    category: "adult_female",
    tone: "ভারী",
    persona: `${FEMALE_CORE} Age about 40. Rich, full, low-alto female voice — mature and grounded, still unmistakably a woman.`,
  },
  {
    id: "af_normal",
    name: "মেহজাবীন",
    engineVoice: "Kore",
    category: "adult_female",
    tone: "স্বাভাবিক",
    persona: `${FEMALE_CORE} Age about 30. Warm, natural, conversational woman's voice, softly expressive.`,
  },
  {
    id: "af_light",
    name: "তানিয়া",
    engineVoice: "Leda",
    category: "adult_female",
    tone: "হালকা",
    persona: `${FEMALE_CORE} Age about 25. Light, airy, bright soprano-leaning woman's voice, gentle and quick.`,
  },
  {
    id: "af_soft",
    name: "রুবাবা",
    engineVoice: "Autonoe",
    category: "adult_female",
    tone: "কোমল",
    persona: `${FEMALE_CORE} Age about 33. Smooth, breathy, intimate woman's voice — close-mic storyteller warmth.`,
  },

  // ---------- Elderly male (45+) ----------
  {
    id: "em_heavy",
    name: "মোজাম্মেল চাচা",
    engineVoice: "Enceladus",
    category: "elderly_male",
    tone: "ভারী",
    persona: `${MALE_CORE} Age about 68. Old man's voice: heavy, weathered, slow, with a soft tremble and breath between phrases. Clearly aged — never youthful.`,
  },
  {
    id: "em_normal",
    name: "আব্দুল করিম",
    engineVoice: "Iapetus",
    category: "elderly_male",
    tone: "স্বাভাবিক",
    persona: `${MALE_CORE} Age about 58. Senior man's voice, measured and wise, slight dryness and age in the throat.`,
  },
  {
    id: "em_light",
    name: "নানাভাই",
    engineVoice: "Umbriel",
    category: "elderly_male",
    tone: "হালকা",
    persona: `${MALE_CORE} Age about 72. Frail, thin, gently shaky elderly male voice, kind and grandfatherly.`,
  },
  {
    id: "em_stern",
    name: "সালাউদ্দিন সাহেব",
    engineVoice: "Rasalgethi",
    category: "elderly_male",
    tone: "কঠোর",
    persona: `${MALE_CORE} Age about 62. Stern, authoritative older man — commanding, clipped, aged but strong.`,
  },

  // ---------- Elderly female (45+) ----------
  {
    id: "ef_heavy",
    name: "রোকেয়া খালা",
    engineVoice: "Gacrux",
    category: "elderly_female",
    tone: "ভারী",
    persona: `${FEMALE_CORE} Age about 65. Older woman's voice: darker, worn alto with age-tremble and slow pacing. Clearly an elderly woman, never a man.`,
  },
  {
    id: "ef_normal",
    name: "আম্মা",
    engineVoice: "Vindemiatrix",
    category: "elderly_female",
    tone: "স্বাভাবিক",
    persona: `${FEMALE_CORE} Age about 55. Mature motherly woman's voice, soft-edged, caring and calm.`,
  },
  {
    id: "ef_light",
    name: "দাদিমা",
    engineVoice: "Achernar",
    category: "elderly_female",
    tone: "হালকা",
    persona: `${FEMALE_CORE} Age about 74. Thin, light, gently quivering grandmother voice, affectionate and slow.`,
  },
  {
    id: "ef_sharp",
    name: "ফিরোজা বেগম",
    engineVoice: "Pulcherrima",
    category: "elderly_female",
    tone: "তীক্ষ্ণ",
    persona: `${FEMALE_CORE} Age about 60. Sharp, opinionated older woman — crisp diction, quick temper, aged brightness.`,
  },

  // ---------- Young boy (<12) ----------
  {
    id: "yb_heavy",
    name: "রাফি",
    engineVoice: "Fenrir",
    category: "young_boy",
    tone: "ভারী",
    persona: `${MALE_CORE} But you are a CHILD of about 11 — a boy, not a man. Small chest, higher pitch than any adult, energetic and slightly husky. Never sound adult or girlish.`,
  },
  {
    id: "yb_normal",
    name: "তামিম",
    engineVoice: "Puck",
    category: "young_boy",
    tone: "স্বাভাবিক",
    persona: `${MALE_CORE} But you are a CHILD of about 8 — a little boy. High, bright, bouncy kid voice with childlike phrasing. Never adult, never girlish.`,
  },
  {
    id: "yb_light",
    name: "নিলয়",
    engineVoice: "Zubenelgenubi",
    category: "young_boy",
    tone: "হালকা",
    persona: `${MALE_CORE} But you are a CHILD of about 6 — a small boy. Very light, soft, innocent little-boy voice, tiny breaths, simple excited delivery.`,
  },
  {
    id: "yb_playful",
    name: "দুষ্টু বাবু",
    engineVoice: "Achird",
    category: "young_boy",
    tone: "দুষ্টু",
    persona: `${MALE_CORE} But you are a CHILD of about 9 — a cheeky boy. Mischievous, giggly, fast little-boy delivery, full of teasing energy.`,
  },

  // ---------- Young girl (<12) ----------
  {
    id: "yg_heavy",
    name: "আনায়া",
    engineVoice: "Erinome",
    category: "young_girl",
    tone: "ভারী",
    persona: `${FEMALE_CORE} But you are a CHILD of about 11 — a girl, not a woman. Fuller kid voice, still clearly a young girl. Never adult, never boyish.`,
  },
  {
    id: "yg_normal",
    name: "মিম",
    engineVoice: "Leda",
    category: "young_girl",
    tone: "স্বাভাবিক",
    persona: `${FEMALE_CORE} But you are a CHILD of about 8 — a little girl. High, sweet, sing-song kid voice with childlike phrasing.`,
  },
  {
    id: "yg_light",
    name: "পরী",
    engineVoice: "Despina",
    category: "young_girl",
    tone: "হালকা",
    persona: `${FEMALE_CORE} But you are a CHILD of about 6 — a tiny girl. Very light, soft, innocent little-girl voice with small breaths.`,
  },
  {
    id: "yg_playful",
    name: "টুনটুনি",
    engineVoice: "Laomedeia",
    category: "young_girl",
    tone: "দুষ্টু",
    persona: `${FEMALE_CORE} But you are a CHILD of about 9 — a playful girl. Giggly, quick, teasing little-girl delivery.`,
  },

  // ---------- Teen boy (13-22) ----------
  {
    id: "tb_heavy",
    name: "শাহরিয়ার",
    engineVoice: "Alnilam",
    category: "teen_boy",
    tone: "ভারী",
    persona: `${MALE_CORE} Age about 21 — a young man whose voice has just settled. Deeper than a teen but still youthful, no adult heaviness, no child brightness.`,
  },
  {
    id: "tb_normal",
    name: "সিয়াম",
    engineVoice: "Schedar",
    category: "teen_boy",
    tone: "স্বাভাবিক",
    persona: `${MALE_CORE} Age about 17 — a teenage boy. Voice recently broken: mid-range, slightly uneven, casual and youthful.`,
  },
  {
    id: "tb_light",
    name: "আদিব",
    engineVoice: "Sadachbia",
    category: "teen_boy",
    tone: "হালকা",
    persona: `${MALE_CORE} Age about 14 — an early-teen boy. Light, thin, still-changing voice with occasional crack. Not a child, not a man.`,
  },
  {
    id: "tb_cool",
    name: "জিসান",
    engineVoice: "Sadaltager",
    category: "teen_boy",
    tone: "স্মার্ট",
    persona: `${MALE_CORE} Age about 19 — a confident college boy. Cool, laid-back, slightly nasal youthful male delivery with slang rhythm.`,
  },

  // ---------- Teen girl (13-22) ----------
  {
    id: "tg_heavy",
    name: "নুসরাত",
    engineVoice: "Callirrhoe",
    category: "teen_girl",
    tone: "ভারী",
    persona: `${FEMALE_CORE} Age about 21 — a young woman just out of her teens. Fuller than a teen, still clearly youthful, never motherly.`,
  },
  {
    id: "tg_normal",
    name: "ঐশী",
    engineVoice: "Aoede",
    category: "teen_girl",
    tone: "স্বাভাবিক",
    persona: `${FEMALE_CORE} Age about 17 — a teenage girl. Bright, expressive, casual teen delivery with fast emotional swings.`,
  },
  {
    id: "tg_light",
    name: "রাইসা",
    engineVoice: "Zephyr",
    category: "teen_girl",
    tone: "হালকা",
    persona: `${FEMALE_CORE} Age about 14 — an early-teen girl. Light, thin, shy-bright voice. Not a small child, not a woman.`,
  },
  {
    id: "tg_bold",
    name: "সুমাইয়া",
    engineVoice: "Algieba",
    category: "teen_girl",
    tone: "সাহসী",
    persona: `${FEMALE_CORE} Age about 19 — a bold college girl. Assertive, quick, confident young female delivery.`,
  },
];

export const LANGS = [
  { id: "bn", label: "বাংলা", sample: "আরে শোনো! আমি সত্যিই ভাবিনি তুমি আসবে… সত্যি বলছি, খুব ভালো লাগছে আমার।" },
  { id: "hi", label: "हिन्दी", sample: "अरे सुनो! मुझे सच में यकीन नहीं था कि तुम आओगे… सच कहूँ तो, बहुत अच्छा लग रहा है।" },
  { id: "ur", label: "اردو", sample: "ارے سنو! مجھے واقعی یقین نہیں تھا کہ تم آؤ گے… سچ کہوں تو بہت اچھا لگ رہا ہے۔" },
] as const;

export type LangId = (typeof LANGS)[number]["id"];

export const voicesByCategory = (id: CategoryId) => VOICES.filter((v) => v.category === id);
export const voiceById = (id: string) => VOICES.find((v) => v.id === id);

/**
 * Explainer-only voice map.
 * High-quality Edge-TTS Neural voice IDs grouped by language, age, and gender.
 * Kept separate from AI Dubbing voices so default dubbing setups remain untouched.
 *
 * Edge-TTS ships no dedicated child voices, so — consistent with how bn and en
 * are handled — child entries map to a lighter, child-sounding Female Neural
 * voice for both genders. All IDs below are verified against the live
 * edge-tts voice list (bn-IN-TanishaaNeural, bn-IN-BashkarNeural,
 * bn-BD-PradeepNeural, bn-BD-NabanitaNeural, en-US-AnaNeural,
 * en-US-AndrewNeural, en-US-AvaNeural, hi-IN-MadhurNeural, hi-IN-SwaraNeural).
 */
export const explainerVoiceMap = {
  bn: {
    child: { male: "bn-IN-TanishaaNeural", female: "bn-IN-TanishaaNeural" },
    adult: { male: "bn-BD-PradeepNeural", female: "bn-BD-NabanitaNeural" },
  },
  en: {
    child: { male: "en-US-AnaNeural", female: "en-US-AnaNeural" },
    adult: { male: "en-US-AndrewNeural", female: "en-US-AvaNeural" },
  },
  hi: {
    child: { male: "hi-IN-SwaraNeural", female: "hi-IN-SwaraNeural" },
    adult: { male: "hi-IN-MadhurNeural", female: "hi-IN-SwaraNeural" },
  },
} as const;

export type ExplainerLang = keyof typeof explainerVoiceMap;
export type ExplainerAge = keyof typeof explainerVoiceMap["bn"];
export type ExplainerGender = keyof typeof explainerVoiceMap["bn"]["adult"];
