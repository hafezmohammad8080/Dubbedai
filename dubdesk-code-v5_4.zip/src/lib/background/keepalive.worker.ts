/// <reference lib="webworker" />
/**
 * Dedicated Web Worker used for background execution during long dubbing runs.
 *
 * Two responsibilities:
 *  1. Heartbeat — worker timers are far less throttled than main-thread timers
 *     when the tab is hidden or the screen is off, so the beat keeps the whole
 *     JS context warm and reports liveness back to the page.
 *  2. Offloaded API communication — chunk analysis / TTS requests are executed
 *     here with `fetch`, so the network work continues while the tab sleeps.
 */

type InMsg =
  | { type: "start"; interval?: number }
  | { type: "stop" }
  | { type: "fetch"; id: string; url: string; init?: { method?: string; headers?: Record<string, string>; body?: string } };

type OutMsg =
  | { type: "beat"; at: number; ticks: number }
  | { type: "fetch:ok"; id: string; status: number; body: string }
  | { type: "fetch:err"; id: string; error: string };

const ctx = self as unknown as DedicatedWorkerGlobalScope;

let timer: ReturnType<typeof setInterval> | null = null;
let ticks = 0;

function post(msg: OutMsg) {
  ctx.postMessage(msg);
}

function start(interval = 1000) {
  if (timer) return;
  timer = setInterval(() => {
    ticks++;
    post({ type: "beat", at: Date.now(), ticks });
    // A tiny same-origin request every ~15s keeps the service worker (and the
    // browser's "this page is doing work" heuristics) alive.
    if (ticks % 15 === 0) {
      void fetch("/__keepalive", { cache: "no-store" }).catch(() => undefined);
    }
  }, interval);
}

function stop() {
  if (timer) clearInterval(timer);
  timer = null;
  ticks = 0;
}

ctx.addEventListener("message", (event: MessageEvent<InMsg>) => {
  const msg = event.data;
  if (!msg) return;

  if (msg.type === "start") return start(msg.interval);
  if (msg.type === "stop") return stop();

  if (msg.type === "fetch") {
    void (async () => {
      try {
        const init: RequestInit = {
          method: msg.init?.method ?? "GET",
          credentials: "same-origin",
        };
        if (msg.init?.headers) init.headers = msg.init.headers;
        if (msg.init?.body != null) init.body = msg.init.body;
        const res = await fetch(msg.url, init);

        post({ type: "fetch:ok", id: msg.id, status: res.status, body: await res.text() });
      } catch (err) {
        post({ type: "fetch:err", id: msg.id, error: err instanceof Error ? err.message : "worker fetch failed" });
      }
    })();
  }
});

export {};
