/**
 * Shared core engine — used by ExplainerView (and available to any future view).
 * All heavy lifting (analysis, TTS, timeline mixing) lives here so a fix or a
 * new capability added once applies everywhere.
 */

import { analyzeChunk, type NonVerbal, type Segment } from "@/lib/dub.functions";
import { hybridChunks, mixTimeline, probeDuration } from "@/lib/audio";
import { voiceById, voicesByCategory, type LangId } from "@/lib/voices";
import { speakWithBrowser, browserTTSAvailable, neuralTTSAvailable } from "@/lib/speech-fallback";
import { resilientFetch, ttsQueue, textQueue, withRecovery, clampThrottle, DEFAULT_THROTTLE_MS, HttpError } from "@/lib/net";
import { notifyFallback } from "@/lib/notify";
import {
  getNeuralVoiceId,
  profileFromCategory,
  toEmotionMode,
  wrapSSML,
  type SupportedLanguage,
} from "@/lib/dubbingLogicHelpers";


/**
 * MODULE 3: configure the anti-flooding delay (500–1000ms) between sequential
 * chunk/dialogue requests for the whole app.
 */
export function setRequestThrottle(ms: number) {
  ttsQueue.setDelay(clampThrottle(ms));
  textQueue.setDelay(clampThrottle(ms));
}
export { DEFAULT_THROTTLE_MS };

/**
 * PRE-BUFFER (anti-glitch): a short delay before an audio chunk actually
 * starts playing, so the decoded buffer is fully ready. Without it the very
 * first samples can be dropped, producing the classic "click/pop" ("tang
 * tang") noise and dialogue overlap between consecutive chunks.
 */
export const PRE_BUFFER_MS = 80; // safe window inside the required 50–100ms

/** Await the pre-buffer window (clamped to 50–100ms). */
export const preBufferDelay = (ms: number = PRE_BUFFER_MS) =>
  new Promise<void>((resolve) =>
    setTimeout(resolve, Math.max(50, Math.min(100, ms))),
  );

/** Decode just to learn how long a synthesized clip is (explainer hold logic). */
async function clipDurationSeconds(audio: ArrayBuffer): Promise<number> {
  try {
    const Ctx =
      (globalThis as unknown as { AudioContext?: typeof AudioContext }).AudioContext;
    if (!Ctx) return 0;
    const ctx = new Ctx();
    const buf = await ctx.decodeAudioData(audio.slice(0));
    await ctx.close();
    return buf.duration;
  } catch {
    return 0;
  }
}

export type EngineProgress = (p: { pct: number; msg: string }) => void;

export type AnalyzeFn = typeof analyzeChunk;

export type SpeakInputClient = {
  voiceId: string;
  lang: LangId;
  text?: string;
  emotion?: string;
  intensity?: number;
  quality?: "fast" | "pro";
};

export type SpeakOutput = {
  /** null → no server audio; the caller should use the browser utterance. */
  audio: ArrayBuffer | null;
  source: "gateway" | "public" | "browser";
  mime: string;
  text: string;
};

/**
 * MODULE 6 (#5 + #7): derive the Edge-TTS neural voice id and the SSML body
 * from the voice/emotion the user already picked in the UI.
 */
export function ttsMeta(input: SpeakInputClient) {
  const voice = voiceById(input.voiceId);
  const { gender, age } = profileFromCategory(voice?.category ?? "adult_male");
  const language = (["bn", "hi", "ur", "en"] as const).includes(
    input.lang as SupportedLanguage,
  )
    ? (input.lang as SupportedLanguage)
    : "bn";
  const emotionMode = toEmotionMode(input.emotion);
  return {
    gender,
    age,
    language,
    emotionMode,
    neuralVoiceId: getNeuralVoiceId(language, gender, age),
    ssml: wrapSSML(input.text ?? "", emotionMode),
  };
}

/**
 * Speak one line through the shared TTS route.
 *
 * MODULE 2: this never throws. Missing key / 429 / 500 all degrade to the
 * free public engine on the server, and finally to a "browser" result the
 * caller renders with `window.speechSynthesis`.
 */

export async function speak(input: SpeakInputClient): Promise<SpeakOutput> {
  const fallback: SpeakOutput = {
    audio: null,
    source: "browser",
    mime: "application/json",
    text: input.text ?? "",
  };
  // MODULE 6 (#5 + #7): the already-selected voice + emotion drive the neural
  // voice id and the SSML payload. No new state, no second request path.
  const meta = ttsMeta(input);
  try {
    // MODULE 3: queued (throttled) + retried with exponential backoff.
    const res = await ttsQueue.add(() =>
      resilientFetch(
        "/api/tts",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...input,
            neuralVoiceId: meta.neuralVoiceId,
            ssml: meta.ssml,
            emotionMode: meta.emotionMode,
          }),
        },
        { label: "tts", retries: 2, baseDelayMs: 1000 },
      ),
    );

    const source = (res.headers.get("X-TTS-Source") ?? "") as SpeakOutput["source"];
    const type = res.headers.get("Content-Type") ?? "";

    if (source === "browser" || type.includes("application/json")) {
      const info = (await res.json().catch(() => ({}))) as { text?: string; reason?: string };
      if (info.reason) console.warn("[engine] TTS degraded to browser:", info.reason);
      notifyFallback(
        /429|limit|quota/i.test(info.reason ?? "")
          ? "API limit reached. Switching to system voice fallback…"
          : "Premium voice unavailable. Using system voice fallback…",
        "tts-fallback",
      );
      return { ...fallback, text: info.text ?? fallback.text };
    }
    return {
      audio: await res.arrayBuffer(),
      source: source || "gateway",
      mime: type || "audio/wav",
      text: input.text ?? "",
    };
  } catch (err) {
    console.warn("[engine] TTS request failed, using browser speech:", err);
    notifyFallback(
      err instanceof HttpError && err.status === 429
        ? "API limit reached. Switching to system voice fallback…"
        : "Voice service unreachable. Switching to system voice fallback…",
      "tts-fallback",
    );
    return fallback;
  }
}

/**
 * Speak + play a line for the user right now. Uses server audio when
 * available, otherwise the native browser voice. Always resolves.
 */
export async function speakAndPlay(
  input: SpeakInputClient,
  audioEl?: HTMLAudioElement | null,
  isExplainerMode?: boolean,
): Promise<SpeakOutput["source"]> {
  const out = await speak(input);
  if (out.audio && out.audio.byteLength > 0) {
    const url = URL.createObjectURL(new Blob([out.audio], { type: out.mime }));
    const el = audioEl ?? new Audio();
    el.src = url;
    // Explainer mode: never time-stretch — natural speech rate (1.0x).
    // Dubbing mode: untouched behaviour (rate stays whatever the caller set).
    if (isExplainerMode === true) el.playbackRate = 1;
    // Pre-buffer so the first samples are ready → no click/pop, no overlap.
    await preBufferDelay();
    await el.play().catch(() => {});
    return out.source;
  }
  if (neuralTTSAvailable() || browserTTSAvailable()) {
    // MODULE 6 (#15): match the native voice to the same speaker profile.
    const { gender, age } = ttsMeta(input);
    await speakWithBrowser(out.text || input.text || "", { lang: input.lang, gender, age });

  }
  return "browser";
}


export type AnalyzeArgs = {
  data: { audioBase64: string; mime: string; offset: number; lang: LangId };
};

/** Decode + chunk + analyse a whole file of any length. */
export async function analyzeFile(opts: {
  file: File;
  lang: LangId;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  analyze: (args: any) => Promise<{ segments: Segment[]; nonverbal: NonVerbal[] }>;
  chunkSeconds?: number;
  onProgress?: EngineProgress;
}): Promise<{ segments: Segment[]; nonverbal: NonVerbal[]; duration: number }> {
  const { file, lang, analyze, chunkSeconds = 60, onProgress } = opts;
  // MODULE 6: no full-file decode — 1-minute slices are streamed through
  // IndexedDB one at a time so hours-long files never blow the heap.
  let duration = await probeDuration(file);
  const segments: Segment[] = [];
  const nonverbal: NonVerbal[] = [];
  let done = 0;
  for await (const chunk of hybridChunks(file, chunkSeconds)) {
    onProgress?.({
      pct: Math.round((done / chunk.total) * 100),
      msg: `অংশ ${done + 1}/${chunk.total} বিশ্লেষণ হচ্ছে…`,
    });
    // A failing chunk must never stop the whole run.
    // MODULE 3: throttled queue + exponential-backoff retry; if every retry
    // fails we keep an empty result and continue instead of halting.
    const out = await textQueue.add(() =>
      withRecovery(
        () =>
          analyze({
            data: { audioBase64: chunk.base64, mime: "wav", offset: chunk.offset, lang },
          }),
        () => ({ segments: [], nonverbal: [] }),
        { label: `chunk-${done + 1}`, retries: 2, baseDelayMs: 1000 },
      ),
    );
    segments.push(...(out.segments ?? []));
    nonverbal.push(...(out.nonverbal ?? []));
    done++;
  }
  if (!duration) duration = segments.reduce((m, s) => Math.max(m, s.end), 0);

  segments.sort((a, b) => a.start - b.start);
  nonverbal.sort((a, b) => a.start - b.start);
  return { segments, nonverbal, duration };
}

/** Synthesize every line and place it on the original timeline. */
export async function renderTimeline(opts: {
  segments: Segment[];
  duration: number;
  lang: LangId;
  /** Pick the voice for a segment. Defaults to the first voice of its category. */
  resolveVoice?: (seg: Segment) => string;
  quality?: "fast" | "pro";
  onProgress?: EngineProgress;
  /** Called for each line that had to fall back to the browser voice. */
  onBrowserFallback?: (seg: Segment) => void;
  /**
   * Explainer mode: skip time-stretching entirely, play at natural speech
   * rate and hold (silence) until the next scene timestamp.
   */
  isExplainerMode?: boolean;
}): Promise<Blob> {
  const {
    segments,
    duration,
    lang,
    resolveVoice,
    quality = "pro",
    onProgress,
    onBrowserFallback,
    isExplainerMode,
  } = opts;
  const explainer = isExplainerMode === true;
  /** Explainer mode only: end of the previously placed clip (no overlap). */
  let cursor = 0;
  const clips: { start: number; audio: ArrayBuffer; target?: number }[] = [];
  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i]!;
    const voiceId =
      resolveVoice?.(seg) ?? voicesByCategory(seg.category)[0]?.id ?? "am_normal";
    const out = await speak({
      voiceId: voiceById(voiceId) ? voiceId : "am_normal",
      lang,
      text: seg.text,
      emotion: seg.emotion,
      intensity: seg.intensity,
      quality,
    });
    // A line with no server audio (no key / rate limited / offline) is spoken
    // live by the browser instead — the render keeps going either way.
    if (out.audio && out.audio.byteLength > 0) {
      if (explainer) {
        // EXPLAINER: no `target` → mixTimeline skips time-stretching, so the
        // TTS plays at its natural 1.0x rate. The clip starts at its scene
        // timestamp (never before the previous clip ended); if it finishes
        // early the timeline simply stays silent — the "pause/hold" until the
        // next scene timestamp.
        const start = Math.max(seg.start, cursor);
        const spoken = await clipDurationSeconds(out.audio);
        cursor = start + (spoken || Math.max(0.3, seg.end - seg.start));
        clips.push({ start, audio: out.audio });
      } else {
        // DUBBING: unchanged — direct time-stretch / lip-sync alignment.
        clips.push({
          start: seg.start,
          audio: out.audio,
          target: Math.max(0.3, seg.end - seg.start),
        });
      }
    } else {
      console.warn(`[engine] line ${i + 1} had no server audio — browser voice fallback`);
      onBrowserFallback?.(seg);
    }
    onProgress?.({
      pct: Math.round(((i + 1) / segments.length) * 100),
      msg: `লাইন ${i + 1}/${segments.length} তৈরি হচ্ছে…`,
    });
    // Anti-glitch pre-buffer between sequential chunks.
    await preBufferDelay();

  }
  return mixTimeline(clips, Math.max(duration, explainer ? cursor : 0));
}
