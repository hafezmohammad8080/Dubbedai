/**
 * Global rapid-click guard.
 *
 * Blocks a second trusted click on the SAME button/link within `windowMs`
 * (default 300ms) so double-taps can never fire duplicate requests.
 * It never disables anything permanently: the lock is per-element and
 * expires purely on elapsed time, so buttons always stay clickable.
 */
const WINDOW_MS = 300;

let installed = false;

export function installGlobalClickGuard(windowMs = WINDOW_MS) {
  if (installed || typeof document === "undefined") return () => {};
  installed = true;

  const lastClickAt = new WeakMap<Element, number>();

  const onClick = (event: MouseEvent) => {
    // Ignore programmatic clicks (e.g. hidden file-input triggers).
    if (!event.isTrusted) return;

    const target = event.target as Element | null;
    const el = target?.closest?.(
      'button, [role="button"], a[download], input[type="submit"]',
    ) as HTMLElement | null;
    if (!el) return;

    const now = Date.now();
    const last = lastClickAt.get(el) ?? 0;
    if (now - last < windowMs) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      return;
    }
    lastClickAt.set(el, now);
  };

  document.addEventListener("click", onClick, true);
  return () => {
    document.removeEventListener("click", onClick, true);
    installed = false;
  };
}
