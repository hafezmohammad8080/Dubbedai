import * as React from "react";

/**
 * Global safety lock for click handlers.
 *
 * - Ignores repeat clicks fired within `windowMs` (default 300ms).
 * - Stays locked for the whole duration of async handlers.
 * - ALWAYS releases in a `finally` block (and on unmount) so a button can
 *   never stay permanently un-clickable.
 */
export function useClickLock(windowMs = 300) {
  const lockedRef = React.useRef(false);
  const lastAtRef = React.useRef(0);
  const timerRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);
  const mountedRef = React.useRef(true);
  const [busy, setBusy] = React.useState(false);

  React.useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      lockedRef.current = false;
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, []);

  const release = React.useCallback(() => {
    lockedRef.current = false;
    if (mountedRef.current) setBusy(false);
  }, []);

  /** Wraps a handler so it can only run once per lock window. */
  const run = React.useCallback(
    <A extends unknown[]>(handler?: (...args: A) => unknown, ...args: A) => {
      if (!handler) return;

      const now = Date.now();
      if (lockedRef.current || now - lastAtRef.current < windowMs) return;

      lockedRef.current = true;
      lastAtRef.current = now;
      setBusy(true);

      let result: unknown;
      try {
        result = handler(...args);
      } catch (error) {
        release();
        throw error;
      }

      if (result && typeof (result as Promise<unknown>).then === "function") {
        // Async handler: keep locked until it settles, then always release.
        void (result as Promise<unknown>).finally(release);
        return;
      }

      // Sync handler: release after the debounce window.
      if (timerRef.current) clearTimeout(timerRef.current);
      timerRef.current = setTimeout(release, windowMs);
    },
    [release, windowMs],
  );

  return { busy, run, release };
}
