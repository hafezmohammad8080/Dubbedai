/**
 * MODULE 6 — pure TypeScript dubbing helpers.
 *
 * Single source of truth for:
 *  #5  Neural voice mapping (Edge TTS voice ids)
 *  #7  SSML emotion wrapping
 *  #12 Pitch (F0) -> speaker profile classification
 *  #15 Native Web Speech fallback voice matching
 *  #16 Clip deduplication + unique id generation
 *
 * No React, no AudioContext, no network — these are consumed by the existing
 * engine/analyzer/overlay modules, never duplicated inside components.
 */

// ============================================================================
// Types & Interfaces
// ============================================================================

export type SupportedLanguage = "bn" | "hi" | "ur" | "en";
export type Gender = "Male" | "Female";
export type AgeGroup = "Adult" | "Child";
export type EmotionMode = "Normal" | "Aggressive" | "Pleading" | "Storytelling";
export type SpeakerProfileType = "Male" | "Female" | "Child";

export interface SpeakerProfile {
  language: SupportedLanguage;
  gender: Gender;
  age: AgeGroup;
}

export interface AudioClip {
  id: string;
  startTime: number;
  endTime: number;
  text: string;
  voiceId?: string;
  emotion?: EmotionMode;
  audioBuffer?: AudioBuffer;
}

// ============================================================================
// Feature #5: Neural Voice Mapper
// ============================================================================

const NEURAL_VOICE_CATALOG: Record<SupportedLanguage, Record<string, string>> = {
  bn: {
    "Male-Adult": "bn-BD-PradeepNeural",
    "Female-Adult": "bn-BD-NabanitaNeural",
    "Male-Child": "bn-IN-BashkarNeural",
    "Female-Child": "bn-IN-TanishaaNeural",
  },
  hi: {
    "Male-Adult": "hi-IN-MadhurNeural",
    "Female-Adult": "hi-IN-SwaraNeural",
    "Male-Child": "hi-IN-KabirNeural",
    "Female-Child": "hi-IN-AnanyaNeural",
  },
  ur: {
    "Male-Adult": "ur-PK-AsadNeural",
    "Female-Adult": "ur-PK-UzmaNeural",
    "Male-Child": "ur-PK-AsadNeural",
    "Female-Child": "ur-PK-UzmaNeural",
  },
  en: {
    "Male-Adult": "en-US-GuyNeural",
    "Female-Adult": "en-US-JennyNeural",
    "Male-Child": "en-US-AnaNeural",
    "Female-Child": "en-US-AnaNeural",
  },
};

/** Maps language + gender + age to an explicit Edge TTS neural voice id. */
export function getNeuralVoiceId(
  language: SupportedLanguage,
  gender: Gender,
  age: AgeGroup,
): string {
  const key = `${gender}-${age}`;
  const langCatalog = NEURAL_VOICE_CATALOG[language] ?? NEURAL_VOICE_CATALOG.en;
  return langCatalog[key] ?? langCatalog["Female-Adult"]!;
}

// ============================================================================
// Feature #7: SSML Emotion Wrapper
// ============================================================================

/** Wraps text into structured SSML based on the target emotional tone. */
export function wrapSSML(text: string, emotion: EmotionMode): string {
  let innerContent: string;

  switch (emotion) {
    case "Aggressive":
      // Volume boost (+6dB), pitch drop, slightly accelerated rate.
      innerContent = `<prosody volume="+6dB" pitch="-5%" rate="+10%">${text}</prosody>`;
      break;

    case "Pleading":
      // Reduced volume, elevated pitch, slightly slower rate.
      innerContent = `<prosody volume="-2dB" pitch="+10%" rate="-5%">${text}</prosody>`;
      break;

    case "Storytelling": {
      // Natural 280ms pause breaks at sentence punctuation.
      const formattedText = text.replace(/([.,!?|])/g, '$1 <break time="280ms"/>');
      innerContent = `<prosody rate="+0%">${formattedText}</prosody>`;
      break;
    }

    case "Normal":
    default:
      // Natural baseline speaking rate (+5%).
      innerContent = `<prosody rate="+5%">${text}</prosody>`;
      break;
  }

  return `<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">${innerContent}</speak>`;
}

// ============================================================================
// Feature #12: Pitch-to-Profile Classifier
// ============================================================================

/**
 * Classifies a speaker from the fundamental frequency (F0):
 *  Male   : 80Hz <= F0 <= 160Hz
 *  Female : 160Hz < F0 <= 250Hz
 *  Child  : F0 > 250Hz
 */
export function classifySpeaker(f0Frequency: number): SpeakerProfileType {
  if (f0Frequency >= 80 && f0Frequency <= 160) return "Male";
  if (f0Frequency > 160 && f0Frequency <= 250) return "Female";
  if (f0Frequency > 250) return "Child";
  // Out-of-bound fallback.
  return f0Frequency < 80 ? "Male" : "Child";
}

// ============================================================================
// Feature #15: Fallback Voice Matching Logic
// ============================================================================

/** Finds the closest native Web Speech voice for a target speaker profile. */
export function findFallbackVoice(
  availableVoices: SpeechSynthesisVoice[],
  targetProfile: SpeakerProfile,
): SpeechSynthesisVoice | null {
  if (!availableVoices || availableVoices.length === 0) return null;

  const langPrefixMap: Record<SupportedLanguage, string> = {
    bn: "bn",
    hi: "hi",
    ur: "ur",
    en: "en",
  };

  const targetLang = langPrefixMap[targetProfile.language] ?? "en";

  // Step 1: language prefix + gender heuristic in the voice name.
  const exactMatch = availableVoices.find((voice) => {
    const matchesLang = voice.lang.toLowerCase().startsWith(targetLang);
    const matchesGender = voice.name.toLowerCase().includes(targetProfile.gender.toLowerCase());
    return matchesLang && matchesGender;
  });
  if (exactMatch) return exactMatch;

  // Step 2: any voice for the target language.
  const langMatch = availableVoices.find((voice) =>
    voice.lang.toLowerCase().startsWith(targetLang),
  );
  if (langMatch) return langMatch;

  // Step 3: global default.
  return availableVoices[0] ?? null;
}

// ============================================================================
// Feature #16: State Deduplication & Unique ID Generator
// ============================================================================

/** Collision-resistant unique clip identifier. */
export function generateUniqueId(): string {
  return `clip_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
}

/**
 * Rejects clips whose timestamp range already exists (within tolerance) and
 * stamps accepted clips with a strict unique id.
 */
export function deduplicateAndAddClips(
  existingClips: AudioClip[],
  newClipData: Omit<AudioClip, "id">,
  toleranceSec: number = 0.1,
): AudioClip[] {
  const isDuplicate = existingClips.some((clip) => {
    const startDiff = Math.abs(clip.startTime - newClipData.startTime);
    const endDiff = Math.abs(clip.endTime - newClipData.endTime);
    return startDiff <= toleranceSec && endDiff <= toleranceSec;
  });

  if (isDuplicate) return existingClips; // duplicate timestamp range rejected

  const validatedClip: AudioClip = { ...newClipData, id: generateUniqueId() };
  return [...existingClips, validatedClip];
}

// ============================================================================
// Bridges to the app's existing vocabulary (no extra state, no new UI)
// ============================================================================

/** App voice category id -> { gender, age } used by the neural mapper. */
export function profileFromCategory(category: string): { gender: Gender; age: AgeGroup } {
  const gender: Gender = category.includes("female") || category.includes("girl") ? "Female" : "Male";
  const age: AgeGroup = category.startsWith("young_") ? "Child" : "Adult";
  return { gender, age };
}

/** Free-form AI emotion label -> one of the four SSML emotion modes. */
export function toEmotionMode(emotion?: string | null): EmotionMode {
  const e = (emotion ?? "").toLowerCase();
  if (/angry|anger|shout|rage|aggress|furious|harsh|intense/.test(e)) return "Aggressive";
  if (/plead|beg|cry|sad|sorrow|fear|scared|weep|desperate/.test(e)) return "Pleading";
  if (/narrat|story|calm-narration|explain|documentar/.test(e)) return "Storytelling";
  return "Normal";
}

/** Pitch classification -> the app's speaker profile fields. */
export function profileFromF0(f0: number): { gender: Gender; age: AgeGroup } {
  const type = classifySpeaker(f0);
  if (type === "Child") return { gender: "Female", age: "Child" };
  return { gender: type, age: "Adult" };
}
