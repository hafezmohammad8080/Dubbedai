import { resilientFetch, ttsQueue, HttpError } from "@/lib/net";

const GATEWAY = "https://ai.gateway.lovable.dev/v1";

export type SpeakInput = {
  text: string;
  engineVoice: string;
  persona: string;
  /** e.g. "angry", "sad", "excited, laughing" */
  emotion?: string | undefined;
  /** 0.5 (whisper) .. 1.5 (shout) */
  intensity?: number | undefined;
  lang: "bn" | "hi" | "ur";
  quality?: "fast" | "pro";
  /** MODULE 6 (#5): Edge-TTS neural voice id resolved from lang+gender+age. */
  neuralVoiceId?: string | undefined;
  /** MODULE 6 (#7): SSML body produced by `wrapSSML()`. */
  ssml?: string | undefined;
  /** MODULE 6 (#7): Normal | Aggressive | Pleading | Storytelling. */
  emotionMode?: string | undefined;
};

const LANG_NAME = { bn: "Bengali (Bangla)", hi: "Hindi", ur: "Urdu" } as const;

/** MODULE 6 (#7): the SSML emotion mode expressed as prosody direction. */
const EMOTION_DIRECTION: Record<string, string> = {
  Aggressive: "Prosody: louder (+6dB), lower pitch (-5%), faster (+10%) — hard and forceful.",
  Pleading: "Prosody: softer (-2dB), higher pitch (+10%), slower (-5%) — begging and fragile.",
  Storytelling: "Prosody: steady storytelling pace with ~280ms pauses at every punctuation mark.",
  Normal: "Prosody: natural baseline pace, roughly +5% of neutral speed.",
};

/**
 * Builds the full direction prefix. Gemini-TTS is steered through the text
 * itself, so persona (gender + age lock), language, emotion and loudness all
 * go in front of the line and are NOT spoken.
 */
export function buildDirection(i: SpeakInput): string {
  const loud =
    (i.intensity ?? 1) >= 1.25
      ? "Raise your volume and push the energy — this line is loud and forceful."
      : (i.intensity ?? 1) <= 0.75
        ? "Drop your volume — this line is quiet, close, almost under your breath."
        : "Keep a natural conversational volume, with normal human rise and fall.";

  return [
    i.persona,
    `Speak in ${LANG_NAME[i.lang]} with a completely natural native accent.`,
    "Perform this as real spoken dialogue from a film — NOT as reading aloud, NOT as narration, NOT cartoonish.",
    i.emotion ? `Emotional state: ${i.emotion}. Let it colour every word.` : "",
    i.emotionMode ? (EMOTION_DIRECTION[i.emotionMode] ?? "") : "",
    loud,
    "Use human imperfection: micro-pauses, breaths, small hesitations, changing pace, stress on the meaningful words, and let sentence endings fall naturally instead of a flat robotic tone.",
    "Say only the dialogue line below, nothing else:",
  ]
    .filter(Boolean)
    .join(" ");
}



export type SynthResult = {
  /** Audio bytes, or null when every server-side engine was unavailable. */
  audio: ArrayBuffer | null;
  /** Which engine produced the bytes. "browser" = caller must use Web Speech. */
  source: "gateway" | "public" | "browser";
  mime: string;
  /** Why the primary engine was skipped/failed (for logs + response header). */
  reason?: string;
};

/** Primary engine: Lovable AI Gateway (Gemini TTS). Throws on any failure. */
async function synthesizeGateway(input: SpeakInput): Promise<ArrayBuffer> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) throw new Error("Missing LOVABLE_API_KEY");

  const model =
    input.quality === "pro" ? "google/gemini-2.5-pro-tts" : "google/gemini-2.5-flash-tts";

  const res = await ttsQueue.add(() =>
    resilientFetch(
      `${GATEWAY}/audio/speech`,
      {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      contents: [
        {
          role: "user",
          parts: [{ text: `${buildDirection(input)}\n\n${input.text}` }],
        },
      ],
          generationConfig: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName: input.engineVoice } },
            },
          },
        }),
      },
      { label: "gateway-tts", retries: 2, baseDelayMs: 1000 },
    ),
  );

  const buf = await res.arrayBuffer();
  if (buf.byteLength < 128) throw new Error("TTS returned empty audio");
  return buf;
}

/** Split text into pieces the free public endpoint accepts (~180 chars). */
function chunkForPublicTTS(text: string, max = 180): string[] {
  const parts = text.match(/[^।.!?\n]+[।.!?\n]*\s*/g) ?? [text];
  const out: string[] = [];
  let cur = "";
  for (const part of parts) {
    if (part.length > max) {
      if (cur.trim()) out.push(cur.trim());
      cur = "";
      for (let i = 0; i < part.length; i += max) out.push(part.slice(i, i + max));
      continue;
    }
    if (cur.length + part.length > max) {
      out.push(cur.trim());
      cur = "";
    }
    cur += part;
  }
  if (cur.trim()) out.push(cur.trim());
  return out.filter(Boolean);
}

/**
 * Free public fallback: key-free Google Translate TTS. Lower quality and no
 * emotion steering, but it keeps audio flowing when the gateway has no key or
 * is rate limited (429) / erroring (5xx).
 */
async function synthesizePublic(input: SpeakInput): Promise<ArrayBuffer> {
  const pieces = chunkForPublicTTS(input.text);
  const buffers: Uint8Array[] = [];
  for (const piece of pieces) {
    const url =
      `https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${input.lang}` +
      `&q=${encodeURIComponent(piece)}`;
    const res = await ttsQueue.add(() =>
      resilientFetch(
        url,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
          },
        },
        { label: "public-tts", retries: 2, baseDelayMs: 1000 },
      ),
    );
    buffers.push(new Uint8Array(await res.arrayBuffer()));
  }
  const total = buffers.reduce((n, b) => n + b.byteLength, 0);
  if (total < 128) throw new Error("Public TTS returned empty audio");
  const merged = new Uint8Array(total);
  let offset = 0;
  for (const b of buffers) {
    merged.set(b, offset);
    offset += b.byteLength;
  }
  return merged.buffer;
}

/**
 * Never-throw synthesis: gateway → free public endpoint → "browser" signal so
 * the client can finish the job with `window.speechSynthesis`.
 */
export async function synthesize(input: SpeakInput): Promise<SynthResult> {
  let reason: string | undefined;

  try {
    return { audio: await synthesizeGateway(input), source: "gateway", mime: "audio/wav" };
  } catch (err) {
    reason =
      err instanceof HttpError
        ? `gateway ${err.status} after retries`
        : err instanceof Error
          ? err.message
          : "gateway error";
    console.warn("[tts] gateway failed, falling back:", reason);
  }

  try {
    return {
      audio: await synthesizePublic(input),
      source: "public",
      mime: "audio/mpeg",
      reason,
    };
  } catch (err) {
    const publicReason = err instanceof Error ? err.message : "public tts error";
    console.warn("[tts] public fallback failed, deferring to browser:", publicReason);
    return {
      audio: null,
      source: "browser",
      mime: "application/json",
      reason: `${reason ?? ""} | ${publicReason}`.trim(),
    };
  }
}

