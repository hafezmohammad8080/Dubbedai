import { useEffect, useState } from "react";
import { Eye, EyeOff, KeyRound, Save, Check, Trash2, Cpu } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import {
  type AiModel,
  type AppSettings,
  loadSettings,
  saveSettings,
  clearSettings,
  purgeKey,
  isFreeMode,
  subscribeSettings,
  MODEL_OPTIONS,
} from "@/lib/settings";
import { notifyInfo, notifySuccess } from "@/lib/notify";
import VoiceSelector from "@/components/VoiceSelector";

/**
 * Settings UI — manage provider API keys and the default AI model.
 *
 * Keys and the model preference are stored in localStorage and loaded on
 * mount. The component is self-contained: drop it anywhere in the app.
 */
export default function Settings() {
  const [geminiKey, setGeminiKey] = useState("");
  const [groqKey, setGroqKey] = useState("");
  const [ttsKey, setTtsKey] = useState("");
  const [model, setModel] = useState<AiModel>("auto");

  const [showGemini, setShowGemini] = useState(false);
  const [showGroq, setShowGroq] = useState(false);
  const [showTts, setShowTts] = useState(false);
  const [saved, setSaved] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const apply = (s: AppSettings) => {
    setGeminiKey(s.geminiKey);
    setGroqKey(s.groqKey);
    setTtsKey(s.ttsKey);
    setModel(s.model);
  };

  // Load saved settings on mount and stay in sync with live changes
  // (same tab or another tab) — MODULE 4: no refresh required.
  useEffect(() => {
    apply(loadSettings());
    setHydrated(true);
    return subscribeSettings(apply);
  }, []);

  const handleSave = () => {
    const next = saveSettings({ geminiKey, groqKey, ttsKey, model });
    setSaved(true);
    notifySuccess(
      isFreeMode(next)
        ? "Saved. No key set — running in Default Free Mode."
        : "Settings saved.",
      "settings-saved",
    );
    window.setTimeout(() => setSaved(false), 2200);
  };

  // Deleting a single field purges it from memory + storage immediately.
  const handlePurge = (field: "geminiKey" | "groqKey" | "ttsKey", label: string) => {
    const next = purgeKey(field);
    notifyInfo(
      isFreeMode(next)
        ? `${label} key removed — switched to Default Free Mode.`
        : `${label} key removed.`,
    );
  };

  const handleClear = () => {
    clearSettings();
    setSaved(false);
    notifyInfo("All keys purged — Default Free Mode active.", "settings-cleared");
  };

  const masked = (v: string) => (hydrated && v ? "•".repeat(Math.min(v.length, 14)) : v);

  return (
    <div className="mx-auto w-full max-w-xl px-4 py-8">
      <Card className="panel">
        <CardHeader className="gap-2">
          <div className="flex items-center gap-2">
            <span className="grid size-9 place-items-center rounded-full bg-primary/15 text-primary">
              <KeyRound className="size-4" />
            </span>
            <div>
              <CardTitle className="text-2xl">API Settings</CardTitle>
              <CardDescription>
                All API keys (Gemini, Groq, TTS) are <strong>(Optional)</strong>. Without a key the
                app runs in Default Free Mode using free public translation and system voices, so
                dubbing never stops. Delete a key any time — it is purged instantly, no refresh
                needed. Your keys stay on this device.
              </CardDescription>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Gemini API key */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="gemini-key">Gemini API Key (Optional)</Label>
              {hydrated && geminiKey ? (
                <button
                  type="button"
                  onClick={() => handlePurge("geminiKey", "Gemini")}
                  className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
                >
                  Remove
                </button>
              ) : null}
            </div>
            <div className="relative">
              <Input
                id="gemini-key"
                type={showGemini ? "text" : "password"}
                autoComplete="off"
                spellCheck={false}
                value={showGemini ? geminiKey : masked(geminiKey)}
                onChange={(e) => setGeminiKey(e.target.value)}
                placeholder="(Optional) — leave empty to use the free fallback"
                className="pr-11"
              />
              <button
                type="button"
                aria-label={showGemini ? "Hide Gemini key" : "Show Gemini key"}
                onClick={() => setShowGemini((s) => !s)}
                className="absolute inset-y-0 right-0 grid place-items-center px-3 text-muted-foreground transition-colors hover:text-foreground"
              >
                {showGemini ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>

          {/* Groq API key */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="groq-key">Groq API Key (Optional)</Label>
              {hydrated && groqKey ? (
                <button
                  type="button"
                  onClick={() => handlePurge("groqKey", "Groq")}
                  className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
                >
                  Remove
                </button>
              ) : null}
            </div>
            <div className="relative">
              <Input
                id="groq-key"
                type={showGroq ? "text" : "password"}
                autoComplete="off"
                spellCheck={false}
                value={showGroq ? groqKey : masked(groqKey)}
                onChange={(e) => setGroqKey(e.target.value)}
                placeholder="(Optional) — leave empty to use the free fallback"
                className="pr-11"
              />
              <button
                type="button"
                aria-label={showGroq ? "Hide Groq key" : "Show Groq key"}
                onClick={() => setShowGroq((s) => !s)}
                className="absolute inset-y-0 right-0 grid place-items-center px-3 text-muted-foreground transition-colors hover:text-foreground"
              >
                {showGroq ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>

          {/* TTS API key (Optional) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between gap-2">
              <Label htmlFor="tts-key">TTS API Key (Optional)</Label>
              {hydrated && ttsKey ? (
                <button
                  type="button"
                  onClick={() => handlePurge("ttsKey", "TTS")}
                  className="text-xs text-muted-foreground underline-offset-2 hover:text-foreground hover:underline"
                >
                  Remove
                </button>
              ) : null}
            </div>
            <div className="relative">
              <Input
                id="tts-key"
                type={showTts ? "text" : "password"}
                autoComplete="off"
                spellCheck={false}
                value={showTts ? ttsKey : masked(ttsKey)}
                onChange={(e) => setTtsKey(e.target.value)}
                placeholder="(Optional) — leave empty to use free / system voices"
                className="pr-11"
              />
              <button
                type="button"
                aria-label={showTts ? "Hide TTS key" : "Show TTS key"}
                onClick={() => setShowTts((s) => !s)}
                className="absolute inset-y-0 right-0 grid place-items-center px-3 text-muted-foreground transition-colors hover:text-foreground"
              >
                {showTts ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
              </button>
            </div>
          </div>

          {/* AI Model selection */}
          <div className="space-y-2">
            <Label htmlFor="ai-model" className="flex items-center gap-2">
              <Cpu className="size-4" /> AI Model
            </Label>
            <Select value={model} onValueChange={(v) => setModel(v as AiModel)}>
              <SelectTrigger id="ai-model" className="w-full">
                <SelectValue placeholder="Select model" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {MODEL_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      <span className="flex flex-col">
                        <span>{opt.label}</span>
                        <span className="text-xs text-muted-foreground">{opt.hint}</span>
                      </span>
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          {/* Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <Button type="button" onClick={handleSave} className="gold-fill">
              <Save className="size-4" />
              Save Settings
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleClear}
              className="text-muted-foreground"
            >
              <Trash2 className="size-4" />
              Clear
            </Button>

            <span
              className={cn(
                "ml-auto inline-flex items-center gap-1.5 text-sm font-medium text-primary transition-opacity duration-200",
                saved ? "opacity-100" : "opacity-0",
              )}
              aria-live="polite"
            >
              <Check className="size-4" />
              Saved
            </span>
          </div>
        </CardContent>
      </Card>

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Voice Engine</CardTitle>
          <CardDescription>
            Microsoft Edge Neural voices, streamed directly in your browser — no server, no API key.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <VoiceSelector />
        </CardContent>
      </Card>
    </div>
  );
}
