import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";
import { useClickLock } from "@/lib/use-click-lock";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline:
          "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  /** External loading state: disables the button and blocks pointer events. */
  isLoading?: boolean;
  /** Double-click lockout window in ms (default 300). */
  lockMs?: number;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { className, variant, size, asChild = false, isLoading, lockMs = 300, onClick, ...props },
    ref,
  ) => {
    const Comp = asChild ? Slot : "button";
    const { busy, run } = useClickLock(lockMs);
    const locked = Boolean(isLoading) || busy;

    return (
      <Comp
        {...props}
        className={cn(
          buttonVariants({ variant, size, className }),
          locked && "pointer-events-none opacity-60",
        )}
        ref={ref}
        aria-busy={locked || undefined}
        disabled={asChild ? undefined : props.disabled || locked}
        onClick={(event: React.MouseEvent<HTMLButtonElement>) => {
          if (locked) {
            event.preventDefault();
            return;
          }
          run(onClick, event);
        }}
      />
    );
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
