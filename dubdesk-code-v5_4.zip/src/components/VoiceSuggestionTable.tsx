/**
 * VoiceSuggestionTable — dashboard for the Fallback Voice Engine.
 *
 * Lists every detected speaker profile, shows whether an internal neural
 * voice matched, and for unmapped profiles renders ranked browser-native
 * fallback suggestions with inline audio preview + manual override controls.
 *
 * Purely additive: it reads existing profiles and writes only into the
 * fallback override store (`@/lib/fallback-voice-engine`).
 */

import { useCallback, useEffect, useMemo, useState } from "react";
import { Loader2, RotateCcw, Sparkles, Square, Volume2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  browserVoicesAvailable,
  cancelPreview,
  loadBrowserVoices,
  loadOverrides,
  previewBrowserVoice,
  previewTextFor,
  resolveEffectiveVoice,
  resolveInternalVoice,
  saveOverrides,
  suggestFallbackVoices,
  voiceKey,
  type OverrideMap,
  type SpeakerProfileInput,
  type VoiceOverride,
} from "@/lib/fallback-voice-engine";

export type VoiceSuggestionTableProps = {
  profiles: SpeakerProfileInput[];
  className?: string;
  /** Notified whenever the effective voice map changes (override or auto). */
  onResolved?: (map: Record<string, VoiceOverride>) => void;
};

export default function VoiceSuggestionTable({
  profiles,
  className,
  onResolved,
}: VoiceSuggestionTableProps) {
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [overrides, setOverrides] = useState<OverrideMap>({});
  const [playing, setPlaying] = useState<string | null>(null);
  const [picked, setPicked] = useState<Record<string, string>>({});

  useEffect(() => {
    setOverrides(loadOverrides());
    let alive = true;
    loadBrowserVoices()
      .then((list) => {
        if (!alive) return;
        setVoices(list);
        setLoading(false);
      })
      .catch(() => alive && setLoading(false));
    return () => {
      alive = false;
      cancelPreview();
    };
  }, []);

  const rows = useMemo(
    () =>
      profiles.map((profile) => {
        const internal = resolveInternalVoice(profile);
        const suggestions = internal ? [] : suggestFallbackVoices(profile, voices, 6);
        return { profile, internal, suggestions };
      }),
    [profiles, voices],
  );

  const effective = useMemo(() => {
    const map: Record<string, VoiceOverride> = {};
    for (const { profile } of rows) {
      const resolved = resolveEffectiveVoice(profile, overrides, voices);
      if (resolved) map[profile.id] = resolved;
    }
    return map;
  }, [rows, overrides, voices]);

  useEffect(() => {
    onResolved?.(effective);
  }, [effective, onResolved]);

  const commit = useCallback((next: OverrideMap) => {
    setOverrides(next);
    saveOverrides(next);
  }, []);

  const preview = useCallback(
    async (rowId: string, key: string, language: SpeakerProfileInput["language"]) => {
      if (playing === rowId) {
        cancelPreview();
        setPlaying(null);
        return;
      }
      cancelPreview();
      setPlaying(rowId);
      await previewBrowserVoice(key, voices, previewTextFor(language));
      setPlaying((cur) => (cur === rowId ? null : cur));
    },
    [playing, voices],
  );

  if (!profiles.length) return null;

  return (
    <section className={className}>
      <div className="flex flex-wrap items-center gap-2">
        <Sparkles className="h-4 w-4 text-muted-foreground" />
        <h3 className="text-sm font-semibold">বিকল্প ভয়েস সাজেশন (Fallback Engine)</h3>
        {loading ? (
          <Badge variant="secondary" className="gap-1">
            <Loader2 className="h-3 w-3 animate-spin" /> ভয়েস লোড হচ্ছে
          </Badge>
        ) : (
          <Badge variant="secondary">{voices.length} browser voices</Badge>
        )}
      </div>

      {!browserVoicesAvailable() && (
        <p className="mt-2 text-xs text-muted-foreground">
          এই ব্রাউজারে native speech synthesis নেই — শুধু ইন্টারনাল নিউরাল ভয়েস ব্যবহার হবে।
        </p>
      )}

      <div className="mt-3 overflow-x-auto rounded-xl border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="min-w-[9rem]">Speaker profile</TableHead>
              <TableHead className="min-w-[10rem]">Internal neural match</TableHead>
              <TableHead className="min-w-[14rem]">Suggested fallback</TableHead>
              <TableHead className="min-w-[8rem] text-right">Preview / Override</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map(({ profile, internal, suggestions }) => {
              const current = effective[profile.id];
              const selectedKey =
                picked[profile.id] ??
                (current?.source === "browser" ? current.value : suggestions[0]?.key) ??
                "";
              const isOverridden = !!overrides[profile.id];
              const selected = suggestions.find((s) => s.key === selectedKey);

              return (
                <TableRow key={profile.id}>
                  <TableCell className="align-top">
                    <div className="font-medium">{profile.label ?? profile.id}</div>
                    <div className="text-xs text-muted-foreground">
                      {profile.language.toUpperCase()} · {profile.gender} · {profile.age}
                      {profile.trait && profile.trait !== "Neutral" ? ` · ${profile.trait}` : ""}
                      {profile.f0 ? ` · ${Math.round(profile.f0)}Hz` : ""}
                    </div>
                  </TableCell>

                  <TableCell className="align-top">
                    {internal ? (
                      <Badge variant="secondary">{internal.label}</Badge>
                    ) : (
                      <Badge variant="destructive">Unmapped</Badge>
                    )}
                    {internal && (
                      <div className="mt-1 font-mono text-[11px] text-muted-foreground">
                        {internal.voiceId}
                      </div>
                    )}
                  </TableCell>

                  <TableCell className="align-top">
                    {suggestions.length ? (
                      <>
                        <Select
                          value={selectedKey}
                          onValueChange={(v) =>
                            setPicked((p) => ({ ...p, [profile.id]: v }))
                          }
                        >
                          <SelectTrigger className="h-9 w-full">
                            <SelectValue placeholder="Select fallback voice" />
                          </SelectTrigger>
                          <SelectContent>
                            {suggestions.map((s) => (
                              <SelectItem key={s.key} value={s.key}>
                                {s.name} · {s.lang} · {s.score}%
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <div className="mt-1 text-[11px] text-muted-foreground">
                          {selected?.reasons.join(" · ") || "browser native"}
                        </div>
                      </>
                    ) : (
                      <span className="text-xs text-muted-foreground">
                        {internal ? "ইন্টারনাল ভয়েসেই চলবে" : "কোনো ব্রাউজার ভয়েস পাওয়া যায়নি"}
                      </span>
                    )}
                    {isOverridden && (
                      <div className="mt-1 text-[11px] font-medium text-primary">
                        Override: {overrides[profile.id]!.label}
                      </div>
                    )}
                  </TableCell>

                  <TableCell className="align-top">
                    <div className="flex flex-wrap justify-end gap-2">
                      <Button
                        type="button"
                        size="sm"
                        variant="outline"
                        disabled={!selectedKey}
                        onClick={() => void preview(profile.id, selectedKey, profile.language)}
                      >
                        {playing === profile.id ? (
                          <Square className="h-3.5 w-3.5" />
                        ) : (
                          <Volume2 className="h-3.5 w-3.5" />
                        )}
                        <span className="ml-1">{playing === profile.id ? "Stop" : "Preview"}</span>
                      </Button>

                      <Button
                        type="button"
                        size="sm"
                        disabled={!selectedKey}
                        onClick={() => {
                          const voice = voices.find((v) => voiceKey(v) === selectedKey);
                          if (!voice) return;
                          commit({
                            ...overrides,
                            [profile.id]: {
                              source: "browser",
                              value: selectedKey,
                              label: `${voice.name} (${voice.lang})`,
                            },
                          });
                        }}
                      >
                        Use this
                      </Button>

                      {isOverridden && (
                        <Button
                          type="button"
                          size="sm"
                          variant="ghost"
                          onClick={() => {
                            const next = { ...overrides };
                            delete next[profile.id];
                            commit(next);
                          }}
                          aria-label="Reset override"
                        >
                          <RotateCcw className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </section>
  );
}
