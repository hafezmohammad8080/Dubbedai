import { useServerFn } from "@tanstack/react-start";
import { useEffect, useRef, useState } from "react";

import { analyzeChunk } from "@/lib/dub.functions";
import { rewriteScriptWithEmotion, generateWithMode } from "@/lib/generate.functions";
import { generateExplainerPrompt } from "@/lib/ai-prompts";
import { analyzeFile, renderTimeline } from "@/lib/engine";
import { fmtTime } from "@/lib/audio";
import { analyzeAudioFile, type AudioCoreAnalysis } from "@/lib/audio-analyzer";
import { useBackgroundExecution } from "@/hooks/useBackgroundExecution";

export type ExplainerLangId = "bn" | "hi" | "ur";
export type ExplainerVoiceId = "male_adult" | "female_adult";
export type ProcessingMode = "fast" | "slow";

/** Hidden narration mood tags produced by generateExplainerPrompt(). */
export type BgmMood = "action" | "sad" | "mystery" | "calm";
const BGM_MOODS: BgmMood[] = ["action", "sad", "mystery", "calm"];
const MOOD_TAG_RE = /\[\s*MOOD\s*:\s*(ACTION|SAD|MYSTERY|CALM)\s*\]/gi;
const BGM_VOLUME = 0.18; // ~18% under the narration voice

/** First hidden mood tag found in a script (defaults to calm). */
function parseMoodTag(text: string): BgmMood {
  MOOD_TAG_RE.lastIndex = 0;
  const m = MOOD_TAG_RE.exec(text);
  const mood = (m?.[1] ?? "").toLowerCase() as BgmMood;
  return BGM_MOODS.includes(mood) ? mood : "calm";
}

/** Remove every hidden mood tag so it is never spoken aloud by the TTS. */
function stripMoodTags(text: string): string {
  return text.replace(MOOD_TAG_RE, " ").replace(/\s{2,}/g, " ").trim();
}

type ExplainerScene = { startTime?: string; endTime?: string; mood?: string; narration?: string };

/** Tolerant JSON extraction from the model output (handles ``` fences). */
function parseExplainerScript(raw: string): { hook: string; scenes: ExplainerScene[] } | null {
  const cleaned = raw.replace(/```json/gi, "").replace(/```/g, "").trim();
  const start = cleaned.indexOf("{");
  const end = cleaned.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const obj = JSON.parse(cleaned.slice(start, end + 1)) as {
      hook?: unknown;
      scenes?: unknown;
    };
    const scenes = Array.isArray(obj.scenes) ? (obj.scenes as ExplainerScene[]) : [];
    return { hook: typeof obj.hook === "string" ? obj.hook : "", scenes };
  } catch {
    return null;
  }
}


const PROCESSING_MODES: { id: ProcessingMode; label: string; hint: string }[] = [
  { id: "fast", label: "⚡ Fast Mode", hint: "Gemini Flash — দ্রুত স্ক্রিপ্ট ড্রাফট" },
  { id: "slow", label: "🎯 Slow Mode", hint: "Gemini Pro — গভীর নির্ভুলতা" },
];

const LANG_NAME: Record<ExplainerLangId, string> = {
  bn: "Bengali",
  hi: "Hindi",
  ur: "Urdu",
};

const EXPLAINER_LANGS: { id: ExplainerLangId; label: string }[] = [
  { id: "bn", label: "Bengali" },
  { id: "hi", label: "Hindi" },
  { id: "ur", label: "Urdu" },
];

const EXPLAINER_VOICES: { id: ExplainerVoiceId; label: string; voiceId: string }[] = [
  { id: "male_adult", label: "Male Adult", voiceId: "am_normal" },
  { id: "female_adult", label: "Female Adult", voiceId: "af_normal" },
];

type Status = { phase: "idle" | "working" | "done" | "error"; msg: string; pct: number };

export default function ExplainerView() {
  const analyze = useServerFn(analyzeChunk);
  const generateNarration = useServerFn(generateWithMode);
  const bg = useBackgroundExecution();

  const [lang, setLang] = useState<ExplainerLangId>("bn");
  const [voice, setVoice] = useState<ExplainerVoiceId>("male_adult");
  const [processingMode, setProcessingMode] = useState<ProcessingMode>("fast");
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>({ phase: "idle", msg: "", pct: 0 });
  const [audioInfo, setAudioInfo] = useState<AudioCoreAnalysis | null>(null);
  const [aiScript, setAiScript] = useState<string>("");
  const [narrationScript, setNarrationScript] = useState<string>("");
  const [bgmMood, setBgmMood] = useState<BgmMood | null>(null);
  const [bgmOn, setBgmOn] = useState(true);
  const fileInput = useRef<HTMLInputElement | null>(null);
  const bgmRef = useRef<HTMLAudioElement | null>(null);
  const narrationRef = useRef<HTMLAudioElement | null>(null);

  // Auto BGM: ambient bed follows the narration player at low volume.
  useEffect(() => {
    const el = bgmRef.current;
    if (el) el.volume = BGM_VOLUME;
  }, [bgmMood, bgmOn]);

  function startBgm() {
    const el = bgmRef.current;
    if (!el || !bgmOn) return;
    el.volume = BGM_VOLUME;
    void el.play().catch(() => {});
  }
  function pauseBgm() {
    bgmRef.current?.pause();
  }


  useEffect(() => () => { if (result) URL.revokeObjectURL(result); }, [result]);

  const busy = status.phase === "working";

  function pick(f: File | null | undefined) {
    if (!f) return;
    setFile(f);
    setResult(null);
    setAudioInfo(null);
    setAiScript("");
    setNarrationScript("");
    setBgmMood(null);

    setStatus({ phase: "idle", msg: "", pct: 0 });
    void analyzeAudioFile(f)
      .then(setAudioInfo)
      .catch(() => setAudioInfo(null));
  }

  async function generate() {
    if (!file) return;
    // Keep the run alive when the tab is hidden or the screen turns off.
    const releaseBg = bg.begin("explainer:generate");
    setResult(null);
    setStatus({ phase: "working", msg: "অডিও ডিকোড হচ্ছে…", pct: 2 });

    try {
      const { segments, duration } = await analyzeFile({
        file,
        lang,
        analyze,
        onProgress: (p) => setStatus({ phase: "working", msg: p.msg, pct: Math.round(p.pct * 0.5) }),
      });
      if (!segments.length) {
        setStatus({ phase: "error", msg: "কোনো কথা পাওয়া যায়নি।", pct: 0 });
        return;
      }
      try {
        const scenes = segments
          .filter((s) => s.text.trim())
          .map((s) => ({
            startTime: s.start.toFixed(2),
            endTime: s.end.toFixed(2),
            originalText: s.text,
          }));
        if (scenes.length) {
          setStatus({ phase: "working", msg: "এআই স্ক্রিপ্ট তৈরি হচ্ছে…", pct: 50 });
          const out = await rewriteScriptWithEmotion({
            data: {
              sourceLanguage: "auto",
              targetLanguage: LANG_NAME[lang],
              voicePersona:
                voice === "male_adult" ? "Male YouTuber" : "Female Storyteller",
              scenes,
              mode: processingMode,
            },
          });
          setAiScript(
            out.scenes
              .map((s) => `[${s.detectedMood.toUpperCase()}] ${s.rewrittenText}`)
              .join("\n\n"),
          );
        }
      } catch (err) {
        setAiScript(`স্ক্রিপ্ট তৈরি করা যায়নি: ${err instanceof Error ? err.message : "unknown"}`);
      }

      // --- AI narration via generateExplainerPrompt() + hidden mood tags ---
      let narrated = segments;
      try {
        setStatus({ phase: "working", msg: "ন্যারেশন স্ক্রিপ্ট তৈরি হচ্ছে…", pct: 55 });
        const transcript = segments
          .filter((s) => s.text.trim())
          .map((s) => `[${s.start.toFixed(2)} - ${s.end.toFixed(2)}] ${s.text}`)
          .join("\n");
        const gen = await generateNarration({
          data: {
            mode: processingMode,
            prompt: generateExplainerPrompt(transcript, LANG_NAME[lang]),
          },
        });
        const rawText = typeof gen?.generated_text === "string" ? gen.generated_text : "";
        const parsed = rawText ? parseExplainerScript(rawText) : null;
        if (parsed && parsed.scenes.length) {
          // BGM mood = first hidden tag in the generated script.
          setBgmMood(parseMoodTag(rawText || String(parsed.scenes[0]?.mood ?? "")));
          setNarrationScript(
            [parsed.hook, ...parsed.scenes.map((s) => s.narration ?? "")]
              .filter(Boolean)
              .join("\n\n"),
          );
          // Map narration onto the timeline, mood tags stripped so the voice
          // never speaks them aloud.
          const spoken = parsed.scenes.map((s) => stripMoodTags(s.narration ?? ""));
          let i = 0;
          narrated = segments.map((s) => {
            if (!s.text.trim()) return s;
            const line = spoken[i++];
            return line ? { ...s, text: line } : s;
          });
        }
      } catch {
        // Narration is an enhancement — never break the render.
      }

      const chosen = EXPLAINER_VOICES.find((v) => v.id === voice)!.voiceId;
      const blob = await renderTimeline({
        segments: narrated,
        duration,
        lang,
        resolveVoice: () => chosen,
        // Explainer: natural 1.0x speech rate + pause/hold, no time-stretching.
        isExplainerMode: true,
        onProgress: (p) =>
          setStatus({ phase: "working", msg: p.msg, pct: 60 + Math.round(p.pct * 0.4) }),
      });

      setResult(URL.createObjectURL(blob));
      setStatus({
        phase: "done",
        msg: `সম্পন্ন! ${segments.length}টি লাইন · ${fmtTime(duration)}`,
        pct: 100,
      });
    } catch (err) {
      setStatus({
        phase: "error",
        msg: `ব্যর্থ: ${err instanceof Error ? err.message : "unknown"}`,
        pct: 0,
      });
    } finally {
      // Release wake lock / worker heartbeat / silent audio loop.
      releaseBg();
    }
  }


  return (
    <main className="mx-auto max-w-3xl px-4 pt-10 pb-24">
      <header className="text-center">
        <span className="inline-block rounded-full border px-3 py-1 text-xs text-muted-foreground">
          ✦ এআই এক্সপ্লেইনার
        </span>
        <h1 className="gold-text mt-4 text-5xl font-bold">AI Explainer</h1>
        <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">
          ফাইল দিন, ভাষা ও ইউটিউবার ভয়েস বেছে নিন — এক ক্লিকে এক্সপ্লেইনার অডিও।
        </p>
      </header>

      <section className="panel mt-8">
        <h2 className="text-lg font-semibold">১. ফাইল</h2>
        <input
          ref={fileInput}
          type="file"
          accept=".mp4,.mp3,.wav,audio/*,video/mp4"
          hidden
          onChange={(e) => pick(e.target.files?.[0])}
        />
        <button
          type="button"
          onClick={() => fileInput.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={(e) => { e.preventDefault(); setDragging(false); pick(e.dataTransfer.files?.[0]); }}
          className={`mt-4 flex w-full flex-col items-center gap-1 rounded-xl border border-dashed bg-secondary/40 px-4 py-8 transition-colors hover:border-primary ${
            dragging ? "border-primary" : ""
          }`}
        >
          <span className="text-base font-medium">{file ? file.name : "↑ ফাইল ড্রপ করুন বা ক্লিক করুন"}</span>
          <span className="text-xs text-muted-foreground">MP4, MP3, WAV</span>
        </button>
        {audioInfo && (
          <p className="mt-3 text-xs text-muted-foreground">
            Emotion: <span className="text-foreground">{audioInfo.detectedEmotion}</span> · Gender:{" "}
            <span className="text-foreground">{audioInfo.detectedGender}</span> · Pitch:{" "}
            {audioInfo.pitchHz} Hz
          </p>
        )}
      </section>

      <section className="panel mt-6">
        <h2 className="text-lg font-semibold">২. সেটিংস</h2>

        <div className="mt-6 grid gap-5 sm:grid-cols-2">
          <label className="block">
            <span className="text-xs text-muted-foreground">Target Language</span>
            <select
              value={lang}
              onChange={(e) => setLang(e.target.value as ExplainerLangId)}
              className="mt-2 w-full rounded-lg border bg-secondary/40 px-3 py-2 text-sm outline-none focus:border-primary"
            >
              {EXPLAINER_LANGS.map((l) => (
                <option key={l.id} value={l.id}>
                  {l.label}
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="text-xs text-muted-foreground">YouTuber Voice</span>
            <select
              value={voice}
              onChange={(e) => setVoice(e.target.value as ExplainerVoiceId)}
              className="mt-2 w-full rounded-lg border bg-secondary/40 px-3 py-2 text-sm outline-none focus:border-primary"
            >
              {EXPLAINER_VOICES.map((v) => (
                <option key={v.id} value={v.id}>
                  {v.label}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div className="mt-5">
          <span className="text-xs text-muted-foreground">Processing Mode</span>
          <div className="mt-2 grid grid-cols-2 gap-2">
            {PROCESSING_MODES.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setProcessingMode(m.id)}
                className={`rounded-lg border px-3 py-2 text-left text-sm transition-colors ${
                  processingMode === m.id
                    ? "border-primary bg-primary/10 font-semibold"
                    : "bg-secondary/40 hover:border-primary/50"
                }`}
              >
                <span className="block">{m.label}</span>
                <span className="block text-[11px] text-muted-foreground">{m.hint}</span>
              </button>
            ))}
          </div>
        </div>

        <p className="mt-6 text-xs text-muted-foreground">
          নির্বাচিত: {EXPLAINER_LANGS.find((l) => l.id === lang)?.label} ·{" "}
          {EXPLAINER_VOICES.find((v) => v.id === voice)?.label} ·{" "}
          {PROCESSING_MODES.find((m) => m.id === processingMode)?.label}
        </p>
      </section>

      <section className="panel mt-6">
        <h2 className="text-lg font-semibold">৩. জেনারেট</h2>
        <button
          type="button"
          disabled={!file || busy}
          onClick={generate}
          className="gold-fill mt-4 w-full rounded-xl py-3 text-sm font-semibold disabled:opacity-40"
        >
          Generate Explainer Audio
        </button>

        {status.msg && (
          <div className="mt-4">
            <div className="h-2 overflow-hidden rounded-full bg-secondary">
              <div className="gold-fill h-full transition-all" style={{ width: `${status.pct}%` }} />
            </div>
            <p
              className={`mt-2 text-xs ${
                status.phase === "error" ? "text-destructive" : "text-muted-foreground"
              }`}
            >
              {status.msg}
            </p>
          </div>
        )}

        {aiScript && (
          <textarea
            readOnly
            value={aiScript}
            rows={8}
            className="mt-4 w-full rounded-lg border bg-secondary/40 px-3 py-2 text-sm outline-none"
          />
        )}

        {narrationScript && (
          <div className="mt-4">
            <span className="text-xs text-muted-foreground">AI Narration (mood-tagged)</span>
            <textarea
              readOnly
              value={narrationScript}
              rows={8}
              className="mt-2 w-full rounded-lg border bg-secondary/40 px-3 py-2 text-sm outline-none"
            />
          </div>
        )}

        {result && (
          <div className="mt-4 space-y-3">
            <audio
              ref={narrationRef}
              src={result}
              controls
              className="w-full"
              onPlay={startBgm}
              onPause={pauseBgm}
              onEnded={pauseBgm}
            />

            {bgmMood && (
              <div className="flex items-center justify-between rounded-lg border bg-secondary/40 px-3 py-2 text-xs">
                <span className="text-muted-foreground">
                  🎵 Auto BGM: <span className="text-foreground">{bgmMood.toUpperCase()}</span> · 18% volume
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setBgmOn((on) => {
                      if (on) bgmRef.current?.pause();
                      return !on;
                    });
                  }}
                  className="rounded-md border px-2 py-1 font-semibold"
                >
                  {bgmOn ? "On" : "Off"}
                </button>
              </div>
            )}

            <a
              href={result}
              download="explainer-audio.wav"
              className="block rounded-xl border py-3 text-center text-sm font-semibold"
            >
              ↓ Download Audio
            </a>
          </div>
        )}

        {bgmMood && (
          <audio ref={bgmRef} src={`/audio/bgm-${bgmMood}.mp3`} loop preload="auto" hidden />
        )}

      </section>
    </main>
  );
}
