/**
 * VoiceSelector — language + voice-type pickers wired to the client-side
 * Microsoft Edge Neural TTS engine (no backend). Shows the exact resolved
 * Neural Voice ID so the mapping is always explicit.
 */

import { Loader2, Pause, Play, Square, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useEffect, useState } from "react";
import { useEdgeTTS } from "@/hooks/useEdgeTTS";
import { TTS_LANGUAGES, VOICE_TYPES, type TtsLanguage, type VoiceType } from "@/lib/neural-voices";

const SAMPLE: Record<TtsLanguage, string> = {
  bn: "আসসালামু আলাইকুম, এটি একটি নিউরাল ভয়েস পরীক্ষা।",
  hi: "नमस्ते, यह एक न्यूरल आवाज़ का परीक्षण है।",
  ur: "السلام علیکم، یہ ایک نیورل آواز کا تجربہ ہے۔",
  en: "Hello, this is a neural voice preview.",
};

export default function VoiceSelector({ className }: { className?: string }) {
  const tts = useEdgeTTS({ language: "bn", voiceType: "Female" });
  const [text, setText] = useState(SAMPLE.bn);
  // Client-only flag: avoids an SSR/hydration mismatch for support warnings.
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const onLanguage = (value: string) => {
    const lang = value as TtsLanguage;
    tts.setLanguage(lang);
    setText((prev) =>
      Object.values(SAMPLE).includes(prev) || !prev.trim() ? SAMPLE[lang] : prev,
    );
  };

  return (
    <div className={className}>
      <div className="flex items-center gap-2">
        <Volume2 className="h-4 w-4 text-muted-foreground" />
        <h3 className="text-sm font-semibold">Neural Voice (Edge TTS)</h3>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="tts-language">Language</Label>
          <Select value={tts.language} onValueChange={onLanguage}>
            <SelectTrigger id="tts-language">
              <SelectValue placeholder="Language" />
            </SelectTrigger>
            <SelectContent>
              {TTS_LANGUAGES.map((l) => (
                <SelectItem key={l.value} value={l.value}>
                  {l.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="tts-voice-type">Voice type</Label>
          <Select
            value={tts.voiceType}
            onValueChange={(v) => tts.setVoiceType(v as VoiceType)}
          >
            <SelectTrigger id="tts-voice-type">
              <SelectValue placeholder="Voice type" />
            </SelectTrigger>
            <SelectContent>
              {VOICE_TYPES.map((v) => (
                <SelectItem key={v.value} value={v.value}>
                  {v.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <p className="mt-3 text-xs text-muted-foreground">
        Active Voice ID: <span className="font-mono text-foreground">{tts.voiceId}</span>
      </p>

      <div className="mt-4 space-y-2">
        <Label htmlFor="tts-text">Preview text</Label>
        <Textarea
          id="tts-text"
          rows={3}
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </div>

      <div className="mt-4 flex flex-wrap gap-2">
        <Button onClick={() => void tts.speak(text)} disabled={tts.isLoading || !text.trim()}>
          {tts.isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Play className="mr-2 h-4 w-4" />
          )}
          {tts.isLoading ? "Synthesizing…" : "Speak"}
        </Button>
        <Button
          variant="secondary"
          onClick={tts.isPaused ? tts.resume : tts.pause}
          disabled={tts.status === "idle" || tts.isLoading}
        >
          {tts.isPaused ? <Play className="mr-2 h-4 w-4" /> : <Pause className="mr-2 h-4 w-4" />}
          {tts.isPaused ? "Resume" : "Pause"}
        </Button>
        <Button variant="outline" onClick={tts.stop} disabled={tts.status === "idle"}>
          <Square className="mr-2 h-4 w-4" />
          Stop
        </Button>
      </div>

      {mounted && !tts.supported && (
        <p className="mt-3 text-xs text-destructive">
          This browser can&apos;t open the neural voice connection; the system voice will be used.
        </p>
      )}
      {tts.error && (
        <p className="mt-3 text-xs text-destructive">
          {tts.error}
          {tts.usedFallback ? " — played with the system voice instead." : ""}
        </p>
      )}
    </div>
  );
}
